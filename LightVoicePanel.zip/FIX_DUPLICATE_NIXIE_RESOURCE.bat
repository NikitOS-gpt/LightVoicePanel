@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RES=%~dp0app\src\main\res"
set "KEEP_BOARD=%~dp0app\src\main\res\drawable-nodpi\nixie_board.png"
if not exist "%RES%" (
  echo Run this file from inside the LightVoicePanel project folder.
  pause
  exit /b 1
)
for /r "%RES%" %%F in (nixie_board.*) do (
  if /I not "%%~fF"=="%KEEP_BOARD%" (
    echo Removing obsolete duplicate: %%~nxF
    del /q "%%~fF"
  )
)
for /L %%N in (0,1,9) do (
  set "KEEP_DIGIT=%~dp0app\src\main\res\drawable-nodpi\nixie_digit_%%N.png"
  for /r "%RES%" %%F in (nixie_digit_%%N.*) do (
    if /I not "%%~fF"=="!KEEP_DIGIT!" (
      echo Removing obsolete digit resource: %%~nxF
      del /q "%%~fF"
    )
  )
)
echo.
echo Done. Canonical Nixie resources are in drawable-nodpi.
pause
