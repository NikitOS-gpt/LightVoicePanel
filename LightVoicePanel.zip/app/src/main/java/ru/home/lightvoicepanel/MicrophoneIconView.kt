package ru.home.lightvoicepanel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Simple monochrome microphone glyph, drawn vectorially so it remains crisp on the tablet. */
class MicrophoneIconView(context: Context, private val tint: Int) : View(context) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tint
        style = Paint.Style.STROKE
        strokeWidth = 1.9f * density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val unit = density
        val mic = android.graphics.RectF(cx - 4.2f * unit, cy - 10f * unit, cx + 4.2f * unit, cy + 3f * unit)
        canvas.drawRoundRect(mic, 4.2f * unit, 4.2f * unit, paint)
        val cradle = Path().apply {
            moveTo(cx - 8f * unit, cy - 1.5f * unit)
            lineTo(cx - 8f * unit, cy + 0.5f * unit)
            cubicTo(cx - 8f * unit, cy + 7.5f * unit, cx + 8f * unit, cy + 7.5f * unit, cx + 8f * unit, cy + 0.5f * unit)
            lineTo(cx + 8f * unit, cy - 1.5f * unit)
        }
        canvas.drawPath(cradle, paint)
        canvas.drawLine(cx, cy + 7.5f * unit, cx, cy + 11f * unit, paint)
        canvas.drawLine(cx - 4.5f * unit, cy + 11f * unit, cx + 4.5f * unit, cy + 11f * unit, paint)
    }
}
