package ru.home.lightvoicepanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

class LightVoiceService : Service(), RecognitionListener {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val work: ExecutorService = Executors.newSingleThreadExecutor()
    @Volatile private var stopped = false
    // Prevent two initialization jobs from opening the microphone concurrently.
    @Volatile private var initializationQueued = false
    private val restartPending = AtomicBoolean(false)
    @Volatile private var microphoneRestartAttempts = 0
    @Volatile private var wakeArmedUntil = 0L
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    @Volatile private var audioRecord: AudioRecord? = null
    @Volatile private var recordingThread: Thread? = null
    @Volatile private var recognitionGeneration = 0L
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastPartialBroadcastAt = 0L
    @Volatile private var lastHandledText = ""
    @Volatile private var lastHandledAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        stopped = false
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Готовлю голосовой движок…"))
        acquireWakeLock()
        if (model == null && audioRecord == null && !initializationQueued) {
            initializationQueued = true
            publishStatus("Подготовка офлайн-распознавания…")
            work.execute { initializeModelAndListener() }
        }
        return START_STICKY
    }

    private fun initializeModelAndListener() {
        try {
            val modelDir = ensureRussianModel()
            if (stopped) return
            publishStatus("Загружаю русскую модель в память…")
            val loadedModel = Model(modelDir.absolutePath)
            model = loadedModel
            if (stopped) {
                loadedModel.close()
                model = null
                return
            }
            startSpeechRecognition()
            initializationQueued = false
            microphoneRestartAttempts = 0
            publishStatus("Слушаю. Скажи «Шайтан батыр»")
            updateNotification("Слушаю ключевую фразу «Шайтан батыр»")
        } catch (e: Exception) {
            initializationQueued = false
            publishStatus("Ошибка голосового движка: ${e.message ?: e.javaClass.simpleName}")
            updateNotification("Ошибка запуска голосового движка")
            if (!stopped && model != null) scheduleRecognitionRestart()
        }
    }

    private fun ensureRussianModel(): File {
        val root = filesDir
        val modelDir = File(root, MODEL_DIR_NAME)
        if (File(modelDir, "conf/model.conf").isFile && File(modelDir, "am/final.mdl").isFile) {
            return modelDir
        }

        if (!isNetworkAvailable()) throw IOException("нет подключения к интернету для первой загрузки модели")
        val zipFile = File(cacheDir, MODEL_ZIP_NAME)
        if (zipFile.exists()) zipFile.delete()
        downloadModel(zipFile)
        if (stopped) throw IOException("загрузка отменена")

        if (modelDir.exists()) modelDir.deleteRecursively()
        val canonicalRoot = root.canonicalPath + File.separator
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (stopped) throw IOException("распаковка отменена")
                val out = File(root, entry.name)
                val canonicalOut = out.canonicalPath
                if (!canonicalOut.startsWith(canonicalRoot)) throw IOException("недопустимый путь в архиве модели")
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    BufferedOutputStream(FileOutputStream(out)).use { output ->
                        val buffer = ByteArray(8192)
                        while (true) {
                            val count = zis.read(buffer)
                            if (count <= 0) break
                            output.write(buffer, 0, count)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        zipFile.delete()
        if (!File(modelDir, "conf/model.conf").isFile || !File(modelDir, "am/final.mdl").isFile) {
            modelDir.deleteRecursively()
            throw IOException("архив загружен, но структура русской модели не найдена")
        }
        return modelDir
    }

    private fun downloadModel(destination: File) {
        publishStatus("Скачиваю русскую модель Vosk (около 45 МБ)…")
        updateNotification("Скачиваю голосовую модель…")
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000
                readTimeout = 30000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("User-Agent", "LightVoicePanel/0.1")
            }
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) throw IOException("сервер модели ответил HTTP $code")
            val total = connection.contentLengthLong
            var received = 0L
            var lastPercent = -1
            BufferedInputStream(connection.inputStream).use { input ->
                FileOutputStream(destination).use { output ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        if (stopped) throw IOException("загрузка отменена")
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        received += n
                        if (total > 0) {
                            val percent = ((received * 100) / total).toInt().coerceIn(0, 100)
                            if (percent / 5 != lastPercent / 5) {
                                lastPercent = percent
                                publishStatus("Скачиваю голосовую модель: $percent%")
                                updateNotification("Скачиваю голосовую модель: $percent%")
                            }
                        }
                    }
                    output.fd.sync()
                }
            }
        } finally {
            connection?.disconnect()
        }
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val network = cm.activeNetworkInfo
            network != null && network.isConnected
        } catch (_: Exception) {
            true
        }
    }

    private fun startSpeechRecognition() {
        val loadedModel = model ?: throw IOException("модель не загружена")
        if (recordingThread?.isAlive == true || audioRecord != null) {
            throw IOException("предыдущая запись микрофона ещё не освобождена")
        }

        val rec = Recognizer(loadedModel, SAMPLE_RATE, JSONArray(buildGrammar()).toString())
        var recorder: AudioRecord? = null
        try {
            // MIC is more compatible with some older Android 7 custom ROMs than
            // Vosk's default VOICE_RECOGNITION source.
            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE.toInt(),
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferBytes = maxOf(if (minBuffer > 0) minBuffer else 0, 6400)
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE.toInt(),
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferBytes
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                throw IOException("Android не смог инициализировать AudioRecord (state=${recorder.state})")
            }

            val activeRecorder = recorder
            val generation = ++recognitionGeneration
            recognizer = rec
            audioRecord = activeRecorder
            val thread = Thread({
                try {
                    activeRecorder.startRecording()
                    if (activeRecorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                        throw IOException("Failed to start recording. Microphone might be already in use.")
                    }

                    val buffer = ShortArray((SAMPLE_RATE * 0.2f).toInt())
                    while (!stopped && !Thread.currentThread().isInterrupted &&
                        audioRecord === activeRecorder && recognitionGeneration == generation) {
                        val count = activeRecorder.read(buffer, 0, buffer.size)
                        if (count < 0) throw IOException("AudioRecord.read завершился с кодом $count")
                        if (count == 0) continue

                        if (rec.acceptWaveForm(buffer, count)) {
                            val result = rec.getResult()
                            mainHandler.post {
                                if (!stopped && recognitionGeneration == generation) onResult(result)
                            }
                        } else {
                            val partial = rec.getPartialResult()
                            mainHandler.post {
                                if (!stopped && recognitionGeneration == generation) onPartialResult(partial)
                            }
                        }
                    }

                    if (!stopped && !Thread.currentThread().isInterrupted &&
                        audioRecord === activeRecorder && recognitionGeneration == generation) {
                        val finalResult = rec.getFinalResult()
                        mainHandler.post {
                            if (!stopped && recognitionGeneration == generation) onFinalResult(finalResult)
                        }
                    }
                } catch (e: Exception) {
                    // The listener callback must outlive the recorder cleanup below.
                    mainHandler.post {
                        if (!stopped && recognitionGeneration == generation) onError(e)
                    }
                } finally {
                    try {
                        if (activeRecorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                            activeRecorder.stop()
                        }
                    } catch (_: Exception) { }
                    try { activeRecorder.release() } catch (_: Exception) { }
                    if (audioRecord === activeRecorder) audioRecord = null
                    if (recordingThread === Thread.currentThread()) recordingThread = null
                }
            }, "LightVoice-AudioRecord")
            recordingThread = thread
            thread.start()
        } catch (e: Exception) {
            try { recorder?.release() } catch (_: Exception) { }
            if (audioRecord === recorder) audioRecord = null
            if (recognizer === rec) recognizer = null
            try { rec.close() } catch (_: Exception) { }
            throw e
        }
    }

    private fun buildGrammar(): List<String> {
        // Vosk uses a restricted grammar, so every common spoken variant must be
        // explicitly present here; otherwise the recognizer may return [unk].
        val commands = linkedSetOf<String>()

        val onVerbs = listOf("включи", "вруби", "зажги", "включай", "врубай")
        val offVerbs = listOf("выключи", "выруби", "погаси", "гаси", "отключи", "отруби", "вырубай", "потуши")
        val powerVerbs = onVerbs + offVerbs + listOf("переключи")
        val lightNouns = listOf("свет", "люстру", "освещение", "лампу", "светильник")

        for (verb in powerVerbs) {
            commands += verb
            for (noun in lightNouns) commands += "$verb $noun"
        }
        commands += listOf(
            "свет включи", "свет вруби", "свет зажги",
            "свет выключи", "свет выруби", "свет погаси", "свет гаси", "потуши свет",
            "выруби всё", "выключи всё", "погаси всё", "гаси всё", "потуши всё",
            "выключи свет совсем", "погаси свет полностью", "погаси огни", "выключи лампу", "выруби лампу"
        )

        val numberForms = mapOf(
            20 to listOf("двадцать", "20"),
            50 to listOf("пятьдесят", "50"),
            100 to listOf("сто", "100")
        )
        for ((_, forms) in numberForms) {
            for (number in forms) {
                commands += listOf(
                    "$number процентов", "$number процент", "на $number процентов", "на $number",
                    "яркость $number", "яркость $number процентов", "яркость на $number",
                    "яркость на $number процентов", "сделай яркость $number",
                    "сделай яркость на $number процентов", "установи яркость $number",
                    "поставь яркость $number", "поставь на $number процентов",
                    "свет на $number", "свет на $number процентов", "люстру на $number",
                    "люстру на $number процентов", "сделай свет на $number процентов"
                )
                for (verb in onVerbs) {
                    commands += listOf(
                        "$verb на $number", "$verb на $number процентов",
                        "$verb свет на $number", "$verb свет на $number процентов",
                        "$verb люстру на $number", "$verb люстру на $number процентов",
                        "$verb свет $number процентов", "$verb люстру $number процентов"
                    )
                }
            }
        }
        commands += listOf(
            "полная яркость", "максимальная яркость", "максимум яркости", "яркость максимум",
            "на максимум", "сделай на максимум", "сделай ярче до максимума",
            "включи максимум", "вруби максимум", "включи на максимум", "вруби на максимум",
            "включи свет на максимум", "вруби свет на максимум",
            "включи свет на сто процентов", "вруби свет на сто процентов",
            "включи люстру на сто процентов", "вруби люстру на сто процентов"
        )

        commands += listOf(
            "ярче", "сделай ярче", "светлее", "прибавь яркость", "увеличь яркость",
            "добавь яркости", "прибавь свет", "темнее", "сделай темнее", "потемнее",
            "убавь яркость", "уменьши яркость", "снизь яркость", "приглуши свет",
            "теплее", "потеплее", "сделай теплее", "сделай свет теплее", "теплый свет",
            "тёплый свет", "более теплый", "более тёплый", "холоднее", "похолоднее",
            "сделай холоднее", "сделай свет холоднее", "холодный свет", "белый холодный",
            "ночник", "включи ночник", "ночной режим", "режим ночника"
        )

        val wakeForms = listOf("шайтан батыр")
        val phrases = linkedSetOf("[unk]")
        phrases.addAll(wakeForms)
        phrases.addAll(commands)
        for (wake in wakeForms) for (command in commands) phrases.add("$wake $command")
        return phrases.toList()
    }

    override fun onResult(hypothesis: String) {
        val text = parseText(hypothesis)
        if (text.isBlank() || text == "[unk]") return
        handleRecognizedText(text)
    }

    override fun onPartialResult(hypothesis: String) {
        val now = System.currentTimeMillis()
        if (now - lastPartialBroadcastAt < 700L) return
        lastPartialBroadcastAt = now
        val text = parseText(hypothesis)
        if (text.isNotBlank() && text != "[unk]") {
            publishStatus(if (System.currentTimeMillis() < wakeArmedUntil) "Слушаю команду…" else "Слушаю ключевую фразу «Шайтан батыр»", "Распознаю: $text")
        }
    }

    override fun onFinalResult(hypothesis: String) {
        // FinalResult is generally used when the recognizer stream stops; onResult handles live segments.
        val text = parseText(hypothesis)
        if (text.isNotBlank() && text != "[unk]") handleRecognizedText(text)
    }

    override fun onError(e: Exception) {
        val message = e.message ?: e.javaClass.simpleName
        publishStatus("Микрофон не запустился: $message. Освобождаю запись и повторяю запуск")
        scheduleRecognitionRestart()
    }

    override fun onTimeout() {
        scheduleRecognitionRestart()
    }

    private fun scheduleRecognitionRestart() {
        if (stopped || model == null || !restartPending.compareAndSet(false, true)) return

        // Avoid a tight restart loop if the ROM or another app currently holds the mic.
        val attempt = microphoneRestartAttempts.coerceAtMost(4)
        val delayMs = when (attempt) {
            0 -> 1200L
            1 -> 3000L
            2 -> 7000L
            else -> 15000L
        }
        microphoneRestartAttempts++

        mainHandler.postDelayed({
            if (stopped || model == null) {
                restartPending.set(false)
                return@postDelayed
            }
            try {
                work.execute {
                    try {
                        releaseRecognitionResources()
                        // Allow Android's audio policy a short moment to release the old recorder.
                        Thread.sleep(400L)
                        startSpeechRecognition()
                        publishStatus("Микрофон перезапущен. Скажи «Шайтан батыр»")
                        updateNotification("Слушаю ключевую фразу «Шайтан батыр»")
                        // If the recorder survives for a while, clear the failure backoff.
                        val activeRecorder = audioRecord
                        val activeGeneration = recognitionGeneration
                        mainHandler.postDelayed({
                            if (!stopped && activeRecorder != null && audioRecord === activeRecorder &&
                                recognitionGeneration == activeGeneration) microphoneRestartAttempts = 0
                        }, 8000L)
                    } catch (e: Exception) {
                        publishStatus("Не удалось открыть микрофон: ${e.message ?: e.javaClass.simpleName}. Повторю позже")
                        mainHandler.postDelayed({
                            restartPending.set(false)
                            scheduleRecognitionRestart()
                        }, 1500L)
                        return@execute
                    } finally {
                        // The actual Vosk callback is delivered on the main thread; it can
                        // safely schedule the next retry after this flag is cleared.
                        restartPending.set(false)
                    }
                }
            } catch (_: Exception) {
                restartPending.set(false)
            }
        }, delayMs)
    }

    private fun releaseRecognitionResources() {
        // Invalidate any callbacks already queued by an older microphone thread.
        recognitionGeneration++
        val oldRecorder = audioRecord
        audioRecord = null
        val oldThread = recordingThread
        recordingThread = null

        try {
            if (oldRecorder?.recordingState == AudioRecord.RECORDSTATE_RECORDING) oldRecorder.stop()
        } catch (_: Exception) { }
        try { oldThread?.interrupt() } catch (_: Exception) { }
        try {
            if (oldThread != null && oldThread !== Thread.currentThread()) oldThread.join(1500L)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (_: Exception) { }
        // The recorder thread normally releases this itself; a second release is guarded.
        try { oldRecorder?.release() } catch (_: Exception) { }

        val oldRecognizer = recognizer
        recognizer = null
        try { oldRecognizer?.close() } catch (_: Exception) { }
    }

    private fun handleRecognizedText(original: String) {
        val normalized = normalize(original)
        val now = System.currentTimeMillis()
        if (normalized == lastHandledText && now - lastHandledAt < 1800L) return
        lastHandledText = normalized
        lastHandledAt = now
        publishStatus("Слушаю ключевую фразу «Шайтан батыр»", "Распознано: «$original»")
        val wakePhrases = listOf("шайтан батыр")
        val wakeFound = wakePhrases.any { normalized.contains(it) }
        if (wakeFound) wakeArmedUntil = now + WAKE_WINDOW_MS

        val action = detectAction(normalized)
        if (action != null && (wakeFound || now < wakeArmedUntil)) {
            wakeArmedUntil = 0L
            publishStatus("Выполняю: ${action.label}", "Распознано: «$original»")
            work.execute { executeAction(action) }
        } else if (wakeFound) {
            publishStatus("Слушаю команду — говори сейчас", "Ключевая фраза: «$original»")
            updateNotification("Жду команду для люстры")
        } else if (action != null) {
            publishStatus("Сначала скажи «Шайтан батыр», затем команду", "Распознано: «$original»")
        }
    }

    private fun detectAction(text: String): LampAction? {
        val t = normalize(text)
        // Specific presets must win over words such as "включи" in phrases
        // like "Шайтан батыр, вруби свет на 100 процентов". The ESP preset
        // command sets a level directly; sending the toggle as well could turn
        // an already-lit lamp off because the ESP API exposes only "power" toggle.
        if (listOf("ночник", "ночной режим", "режим ночника").any { t.contains(normalize(it)) }) {
            return LampAction.NIGHT_SEQUENCE
        }

        if (containsAnyPhrase(t, listOf(
                "двадцать процентов", "двадцать процент", "на двадцать", "яркость двадцать",
                "20 процентов", "20 процент", "на 20", "яркость 20", "двадцать", "20"
            ))) return LampAction.BRIGHTNESS_20

        if (containsAnyPhrase(t, listOf(
                "пятьдесят процентов", "пятьдесят процент", "на пятьдесят", "яркость пятьдесят",
                "50 процентов", "50 процент", "на 50", "яркость 50", "пятьдесят", "50"
            ))) return LampAction.BRIGHTNESS_50

        if (containsAnyPhrase(t, listOf(
                "сто процентов", "сто процент", "на сто", "яркость сто", "сто процентов яркости", "сто",
                "100 процентов", "100 процент", "на 100", "яркость 100", "100", "полная яркость",
                "максимальная яркость", "максимум яркости", "яркость максимум", "на максимум",
                "сделай на максимум", "до максимума"
            ))) return LampAction.BRIGHTNESS_100

        if (listOf("теплее", "потеплее", "теплый свет", "более теплый", "свет теплее", "сделай теплее")
                .any { t.contains(normalize(it)) }) return LampAction.WARMER
        if (listOf("холоднее", "похолоднее", "холодный свет", "белый холодный", "свет холоднее", "сделай холоднее")
                .any { t.contains(normalize(it)) }) return LampAction.COOLER
        if (listOf("ярче", "светлее", "прибавь яркость", "увеличь яркость", "добавь яркости", "прибавь свет")
                .any { t.contains(normalize(it)) }) return LampAction.BRIGHTER
        if (listOf("темнее", "потемнее", "убавь яркость", "уменьши яркость", "снизь яркость", "приглуши свет")
                .any { t.contains(normalize(it)) }) return LampAction.DIMMER

        // The ESP's "power" command is a toggle, so on/off synonyms both map
        // to it. Fixed brightness phrases above take precedence over the verb.
        val powerPhrases = listOf(
            "включи", "вруби", "зажги", "включай", "врубай", "выключи", "выруби", "вырубай",
            "погаси", "гаси", "отключи", "отруби", "потуши", "переключи"
        )
        if (containsAnyPhrase(t, powerPhrases)) return LampAction.POWER_TOGGLE
        return null
    }

    private fun containsAnyPhrase(text: String, phrases: List<String>): Boolean {
        return phrases.any { phrase ->
            val normalizedPhrase = normalize(phrase)
            Regex("(^|\\s)${Regex.escape(normalizedPhrase)}(\\s|$)").containsMatchIn(text)
        }
    }

    private fun executeAction(action: LampAction) {
        try {
            // The ESP8266 web UI exposes /cmd?name=COMMAND. Send the same symbolic
            // command names as its buttons instead of raw IR hex codes.
            val commands = when (action) {
                LampAction.POWER_TOGGLE -> listOf("power")
                LampAction.BRIGHTER -> listOf("brighter")
                LampAction.DIMMER -> listOf("darker")
                LampAction.BRIGHTNESS_20 -> listOf("20")
                LampAction.BRIGHTNESS_50 -> listOf("50")
                LampAction.BRIGHTNESS_100 -> listOf("100")
                LampAction.WARMER -> listOf("warmer")
                LampAction.COOLER -> listOf("cooler")
                // This deliberately does NOT send the ESP's saved night preset:
                // it runs the four requested actions as separate HTTP commands.
                LampAction.NIGHT_SEQUENCE -> listOf("night", "warmer", "darker", "darker")
            }
            val base = getSharedPreferences(PREFS, MODE_PRIVATE).getString("controller_base", "")?.trim().orEmpty().trimEnd('/')
            if (base.isBlank()) {
                publishStatus("Голос распознан; укажи адрес ESP8266 для управления люстрой", "Команда: ${action.label}. Контроллер не настроен.")
                return
            }
            for ((index, command) in commands.withIndex()) {
                val response = sendControllerCommand(base, command)
                if (response !in 200..299) {
                    publishStatus("HTTP $response при отправке команды «$command»", "Команда: ${action.label}")
                    return
                }
                if (action == LampAction.NIGHT_SEQUENCE && index < commands.lastIndex) Thread.sleep(NIGHT_STEP_DELAY_MS)
            }
            publishStatus("Команда отправлена: ${action.label}", "API: ${commands.joinToString(" → ")}")
            updateNotification("Слушаю ключевую фразу «Шайтан батыр»")
        } catch (e: Exception) {
            publishStatus("Ошибка отправки ИК-команды: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun sendControllerCommand(base: String, command: String): Int {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val savedRoute = prefs.getString("controller_route", null)?.trim().orEmpty()
        // Migrate the old example route automatically; that endpoint is not in the ESP web UI.
        val template = if (savedRoute.isBlank() || savedRoute == "/ir?code={code}") {
            "/cmd?name={command}"
        } else {
            savedRoute
        }
        // Keep {code} as a compatibility alias for anyone who manually used that placeholder.
        val path = template.replace("{command}", command).replace("{code}", command)
        val separator = if (path.startsWith("/")) "" else "/"
        val address = if (base.startsWith("http://", true) || base.startsWith("https://", true)) base else "http://$base"
        val url = URL(address + separator + path)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 2500
            readTimeout = 2500
            useCaches = false
        }
        return try {
            connection.connect()
            val status = connection.responseCode
            try { if (status >= 400) connection.errorStream?.close() else connection.inputStream?.close() } catch (_: Exception) { }
            status
        } finally {
            connection.disconnect()
        }
    }

    private fun parseText(json: String): String = try {
        JSONObject(json).optString("text", "").trim()
    } catch (_: Exception) { json.trim() }

    private fun normalize(value: String): String = value.lowercase(Locale("ru", "RU"))
        .replace('ё', 'е')
        .replace(Regex("[^\\p{L}\\p{N} ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun publishStatus(status: String, last: String? = null) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val editor = prefs.edit().putString("voice_status", status)
        if (last != null) editor.putString("last_recognized", last)
        editor.apply()
        val intent = Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_STATUS, status)
        if (last != null) intent.putExtra(EXTRA_LAST, last)
        sendBroadcast(intent)
        updateNotification(status)
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == true) return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:VoiceListening").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) { }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Голосовое управление светом", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Показывает, что планшет слушает локальные команды люстры"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag()
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, LightVoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag()
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        builder.setContentTitle("Голосовое управление светом")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(null, "Остановить", stopIntent).build())
        return builder.build()
    }

    private fun immutableFlag(): Int = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0

    private fun updateNotification(message: String) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildNotification(message))
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        stopped = true
        try { mainHandler.removeCallbacksAndMessages(null) } catch (_: Exception) { }
        releaseRecognitionResources()
        try { model?.close() } catch (_: Exception) { }
        model = null
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
        work.shutdownNow()
        publishStatus("Прослушивание остановлено")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            stopForeground(true)
        }
        super.onDestroy()
    }

    private enum class LampAction(val label: String) {
        POWER_TOGGLE("включение/выключение света"),
        BRIGHTER("ярче"),
        DIMMER("темнее"),
        BRIGHTNESS_20("яркость 20%"),
        BRIGHTNESS_50("яркость 50%"),
        BRIGHTNESS_100("яркость 100%"),
        WARMER("теплее"),
        COOLER("холоднее"),
        NIGHT_SEQUENCE("ночник: Ночник → Теплее → Темнее → Темнее")
    }

    companion object {
        const val PREFS = "light_voice_panel"
        const val ACTION_START = "ru.home.lightvoicepanel.START"
        const val ACTION_STOP = "ru.home.lightvoicepanel.STOP"
        const val ACTION_STATUS = "ru.home.lightvoicepanel.STATUS"
        const val EXTRA_STATUS = "status"
        const val EXTRA_LAST = "last"
        private const val CHANNEL_ID = "light_voice_service"
        private const val NOTIFICATION_ID = 4107
        private const val SAMPLE_RATE = 16000.0f
        private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip"
        private const val MODEL_DIR_NAME = "vosk-model-small-ru-0.22"
        private const val MODEL_ZIP_NAME = "vosk-model-small-ru-0.22.zip"
        private const val WAKE_WINDOW_MS = 9000L
        private const val NIGHT_STEP_DELAY_MS = 300L
    }
}
