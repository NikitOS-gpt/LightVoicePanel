package ru.home.lightvoicepanel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.net.HttpURLConnection
import java.net.URL

/** Delivers a scheduled lighting scene without launching the dashboard UI. */
class LampAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != LampAlarmScheduler.ACTION_FIRE) return
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences(LightVoiceService.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("lamp_alarm_enabled", false)) return

        val mode = prefs.getString("lamp_alarm_mode", "100") ?: "100"
        val commands = LampAlarmScheduler.commandsForMode(mode)
        // Plan the next selected weekday before doing network I/O so this is a weekly alarm.
        LampAlarmScheduler.scheduleNext(appContext, System.currentTimeMillis() + 1_000L)

        val pending = goAsync()
        Thread({
            var result = "OK"
            try {
                for ((index, command) in commands.withIndex()) {
                    val status = sendCommand(appContext, command)
                    if (status !in 200..299) {
                        result = "HTTP $status ($command)"
                        break
                    }
                    if (index < commands.lastIndex) Thread.sleep(350L)
                }
            } catch (e: Exception) {
                result = "ERROR: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                prefs.edit()
                    .putLong("lamp_alarm_last_run", System.currentTimeMillis())
                    .putString("lamp_alarm_last_result", result)
                    .apply()
                pending.finish()
            }
        }, "LightVoice-LampAlarm").start()
    }

    private fun sendCommand(context: Context, command: String): Int {
        val prefs = context.getSharedPreferences(LightVoiceService.PREFS, Context.MODE_PRIVATE)
        val base = prefs.getString("controller_base", "http://192.168.0.10")?.trim().orEmpty()
        val routePref = prefs.getString("controller_route", "/cmd?name={command}")?.trim().orEmpty()
        val route = if (routePref.isBlank() || routePref == "/ir?code={code}") "/cmd?name={command}" else routePref
        val path = route.replace("{command}", command).replace("{code}", command)
        val baseUrl = if (base.startsWith("http://", true) || base.startsWith("https://", true)) base else "http://$base"
        val connection = (URL(baseUrl.trimEnd('/') + (if (path.startsWith("/")) path else "/$path")).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 1800
            readTimeout = 1800
            useCaches = false
        }
        return try {
            connection.connect()
            val code = connection.responseCode
            try { if (code >= 400) connection.errorStream?.close() else connection.inputStream?.close() } catch (_: Exception) { }
            code
        } finally {
            connection.disconnect()
        }
    }
}
