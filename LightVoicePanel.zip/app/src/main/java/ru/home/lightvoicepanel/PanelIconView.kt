package ru.home.lightvoicepanel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Lightweight vector icons drawn locally, avoiding missing-glyph boxes on older Android builds. */
class PanelIconView(
    context: Context,
    private val iconName: String,
    private val tint: Int
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tint
        style = Paint.Style.STROKE
        strokeWidth = 2.25f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tint
        style = Paint.Style.FILL
    }
    private val rect = RectF()
    private val path = Path()

    init {
        isClickable = false
        isFocusable = false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val fit = when (iconName) {
            "home", "cloudsun", "mic", "settings", "list", "bulb", "leaf", "wifi", "cloud", "rain", "snow", "fog", "sun", "alarm" -> 0.76f
            else -> 0.58f
        }
        val s = min(width, height).toFloat() / 48f * fit
        if (s <= 0f) return
        canvas.save()
        canvas.translate((width - 48f * s) / 2f, (height - 48f * s) / 2f)
        canvas.scale(s, s)
        paint.strokeWidth = 2.3f
        fillPaint.color = tint
        when (iconName) {
            "power" -> drawPower(canvas)
            "moon" -> drawMoon(canvas)
            "sun" -> drawSun(canvas, false, false)
            "sunUp" -> drawSun(canvas, true, false)
            "sunDown" -> drawSun(canvas, false, true)
            "thermometer" -> drawThermometer(canvas)
            "flame" -> drawFlame(canvas)
            "snowflake" -> drawSnowflake(canvas)
            "home" -> drawHome(canvas)
            "cloudsun" -> drawCloudSun(canvas)
            "cloud" -> drawCloud(canvas)
            "rain" -> drawRain(canvas)
            "snow" -> drawSnow(canvas)
            "fog" -> drawFog(canvas)
            "leaf" -> drawLeaf(canvas)
            "wifi" -> drawWifi(canvas)
            "bulb" -> drawBulb(canvas)
            "list" -> drawList(canvas)
            "mic" -> drawMic(canvas)
            "settings" -> drawSettings(canvas)
            "alarm" -> drawAlarm(canvas)
            else -> drawSun(canvas, false, false)
        }
        canvas.restore()
    }

    private fun drawPower(c: Canvas) {
        rect.set(9f, 12f, 39f, 42f)
        c.drawArc(rect, 43f, 274f, false, paint)
        c.drawLine(24f, 4f, 24f, 25f, paint)
    }

    private fun drawMoon(c: Canvas) {
        path.reset()
        path.moveTo(29f, 5.5f)
        path.cubicTo(16f, 7f, 9f, 18f, 13f, 29f)
        path.cubicTo(18f, 42f, 34f, 43f, 41f, 31f)
        path.cubicTo(34f, 34f, 25f, 29f, 23f, 20f)
        path.cubicTo(21f, 14f, 24f, 8f, 29f, 5.5f)
        path.close()
        c.drawPath(path, paint)
    }

    private fun drawSun(c: Canvas, plus: Boolean, minus: Boolean) {
        c.drawCircle(24f, 23f, 8f, paint)
        for (i in 0..7) {
            val a = Math.toRadians(i * 45.0)
            val x1 = 24f + cos(a).toFloat() * 13f
            val y1 = 23f + sin(a).toFloat() * 13f
            val x2 = 24f + cos(a).toFloat() * 18f
            val y2 = 23f + sin(a).toFloat() * 18f
            c.drawLine(x1, y1, x2, y2, paint)
        }
        if (plus || minus) {
            paint.strokeWidth = 3f
            c.drawLine(33f, 35f, 43f, 35f, paint)
            if (plus) c.drawLine(38f, 30f, 38f, 40f, paint)
            paint.strokeWidth = 2.3f
        }
    }

    private fun drawThermometer(c: Canvas) {
        path.reset()
        path.moveTo(20f, 26f)
        path.lineTo(20f, 10f)
        path.cubicTo(20f, 4f, 28f, 4f, 28f, 10f)
        path.lineTo(28f, 26f)
        path.cubicTo(32f, 29f, 34f, 33f, 32f, 37f)
        path.cubicTo(29f, 44f, 19f, 44f, 16f, 37f)
        path.cubicTo(14f, 33f, 16f, 29f, 20f, 26f)
        path.close()
        c.drawPath(path, paint)
        c.drawLine(24f, 13f, 24f, 33f, paint)
        c.drawCircle(24f, 36f, 3.4f, paint)
    }

    private fun drawFlame(c: Canvas) {
        path.reset()
        path.moveTo(25f, 5f)
        path.cubicTo(27f, 14f, 39f, 18f, 36f, 29f)
        path.cubicTo(35f, 38f, 29f, 43f, 22f, 42f)
        path.cubicTo(12f, 40f, 10f, 31f, 15f, 23f)
        path.cubicTo(16f, 30f, 21f, 29f, 21f, 23f)
        path.cubicTo(21f, 17f, 23f, 12f, 25f, 5f)
        path.close()
        c.drawPath(path, paint)
        path.reset()
        path.moveTo(25f, 25f)
        path.cubicTo(31f, 31f, 28f, 38f, 23f, 38f)
        path.cubicTo(18f, 37f, 19f, 31f, 25f, 25f)
        path.close()
        c.drawPath(path, paint)
    }

    private fun drawSnowflake(c: Canvas) {
        val cx = 24f; val cy = 24f
        for (i in 0..5) {
            val a = Math.toRadians(i * 60.0)
            val dx = cos(a).toFloat(); val dy = sin(a).toFloat()
            c.drawLine(cx - dx * 17f, cy - dy * 17f, cx + dx * 17f, cy + dy * 17f, paint)
            for (sign in floatArrayOf(-1f, 1f)) {
                val bx = cx + dx * 9f * sign
                val by = cy + dy * 9f * sign
                val branchX = -dy * 5f
                val branchY = dx * 5f
                c.drawLine(bx, by, bx - dx * 4f + branchX, by - dy * 4f + branchY, paint)
                c.drawLine(bx, by, bx - dx * 4f - branchX, by - dy * 4f - branchY, paint)
            }
        }
    }

    private fun drawHome(c: Canvas) {
        path.reset()
        path.moveTo(5f, 22f); path.lineTo(24f, 5f); path.lineTo(43f, 22f)
        c.drawPath(path, paint)
        path.reset()
        path.moveTo(11f, 20f); path.lineTo(11f, 42f); path.lineTo(37f, 42f); path.lineTo(37f, 20f)
        c.drawPath(path, paint)
        rect.set(20f, 29f, 28f, 42f)
        c.drawRect(rect, paint)
    }

    private fun drawCloudSun(c: Canvas) {
        c.drawCircle(33f, 12f, 5.5f, paint)
        for (i in 0..7) {
            val a = Math.toRadians(i * 45.0)
            c.drawLine(33f + cos(a).toFloat() * 8f, 12f + sin(a).toFloat() * 8f,
                33f + cos(a).toFloat() * 11f, 12f + sin(a).toFloat() * 11f, paint)
        }
        path.reset()
        path.moveTo(36f, 33f)
        path.cubicTo(42f, 33f, 44f, 29f, 42f, 25f)
        path.cubicTo(40f, 21f, 36f, 21f, 33f, 23f)
        path.cubicTo(31f, 15f, 20f, 15f, 17f, 23f)
        path.cubicTo(8f, 22f, 5f, 29f, 9f, 34f)
        path.cubicTo(11f, 37f, 15f, 37f, 19f, 37f)
        path.lineTo(36f, 37f)
        c.drawPath(path, paint)
    }

    private fun drawCloud(c: Canvas) {
        path.reset()
        path.moveTo(37f, 36f)
        path.cubicTo(43f, 36f, 45f, 31f, 42f, 26f)
        path.cubicTo(40f, 22f, 36f, 21f, 32f, 23f)
        path.cubicTo(29f, 13f, 17f, 14f, 15f, 23f)
        path.cubicTo(7f, 22f, 5f, 28f, 8f, 33f)
        path.cubicTo(10f, 37f, 14f, 37f, 19f, 37f)
        path.close()
        c.drawPath(path, paint)
    }

    private fun drawRain(c: Canvas) {
        drawCloud(c)
        c.drawLine(17f, 34f, 13f, 42f, paint)
        c.drawLine(27f, 34f, 23f, 42f, paint)
        c.drawLine(37f, 34f, 33f, 42f, paint)
    }

    private fun drawSnow(c: Canvas) {
        drawCloud(c)
        for (x in floatArrayOf(15f, 25f, 35f)) {
            c.drawCircle(x, 40f, 2f, fillPaint)
        }
    }

    private fun drawFog(c: Canvas) {
        drawCloud(c)
        c.drawLine(8f, 39f, 40f, 39f, paint)
        c.drawLine(13f, 44f, 35f, 44f, paint)
    }

    private fun drawLeaf(c: Canvas) {
        path.reset()
        path.moveTo(9f, 38f)
        path.cubicTo(7f, 14f, 25f, 6f, 41f, 8f)
        path.cubicTo(41f, 25f, 30f, 40f, 9f, 38f)
        c.drawPath(path, paint)
        c.drawLine(10f, 38f, 32f, 17f, paint)
        c.drawLine(22f, 27f, 20f, 18f, paint)
        c.drawLine(25f, 24f, 34f, 25f, paint)
    }

    private fun drawWifi(c: Canvas) {
        rect.set(7f, 5f, 41f, 39f); c.drawArc(rect, 220f, 100f, false, paint)
        rect.set(13f, 12f, 35f, 35f); c.drawArc(rect, 220f, 100f, false, paint)
        rect.set(19f, 19f, 29f, 29f); c.drawArc(rect, 220f, 100f, false, paint)
        c.drawCircle(24f, 38f, 2.5f, fillPaint)
    }

    private fun drawBulb(c: Canvas) {
        path.reset()
        path.moveTo(15f, 19f)
        path.cubicTo(15f, 7f, 33f, 7f, 33f, 19f)
        path.cubicTo(33f, 25f, 28f, 28f, 28f, 32f)
        path.lineTo(20f, 32f)
        path.cubicTo(20f, 28f, 15f, 25f, 15f, 19f)
        c.drawPath(path, paint)
        c.drawLine(20f, 36f, 28f, 36f, paint)
        c.drawLine(21f, 40f, 27f, 40f, paint)
        c.drawLine(24f, 1.5f, 24f, 5f, paint)
        c.drawLine(6f, 18f, 10f, 18f, paint)
        c.drawLine(38f, 18f, 42f, 18f, paint)
    }

    private fun drawList(c: Canvas) {
        rect.set(7f, 8f, 41f, 40f); c.drawRoundRect(rect, 5f, 5f, paint)
        for (y in floatArrayOf(17f, 24f, 31f)) {
            c.drawCircle(14f, y, 1.1f, fillPaint)
            c.drawLine(20f, y, 34f, y, paint)
        }
    }

    private fun drawMic(c: Canvas) {
        rect.set(17f, 4f, 31f, 29f); c.drawRoundRect(rect, 7f, 7f, paint)
        path.reset(); path.moveTo(11f, 22f); path.cubicTo(11f, 40f, 37f, 40f, 37f, 22f)
        c.drawPath(path, paint)
        c.drawLine(24f, 39f, 24f, 44f, paint)
        c.drawLine(17f, 44f, 31f, 44f, paint)
    }

    private fun drawAlarm(c: Canvas) {
        // Classic alarm-clock silhouette with bells and short legs.
        rect.set(10f, 13f, 38f, 40f)
        c.drawCircle(24f, 27f, 13f, paint)
        c.drawLine(24f, 27f, 24f, 19f, paint)
        c.drawLine(24f, 27f, 31f, 30f, paint)
        c.drawArc(RectF(5f, 3f, 19f, 16f), 205f, 150f, false, paint)
        c.drawArc(RectF(29f, 3f, 43f, 16f), 185f, 150f, false, paint)
        c.drawLine(14f, 39f, 10f, 44f, paint)
        c.drawLine(34f, 39f, 38f, 44f, paint)
    }

    private fun drawSettings(c: Canvas) {
        c.drawCircle(24f, 24f, 8f, paint)
        c.drawCircle(24f, 24f, 2.5f, paint)
        for (i in 0..7) {
            val a = Math.toRadians(i * 45.0)
            c.drawLine(24f + cos(a).toFloat() * 12f, 24f + sin(a).toFloat() * 12f,
                24f + cos(a).toFloat() * 18f, 24f + sin(a).toFloat() * 18f, paint)
        }
    }
}
