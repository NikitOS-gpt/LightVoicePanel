package ru.home.lightvoicepanel

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.HorizontalScrollView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import org.json.JSONObject
import java.util.concurrent.Executors

/** Main LightVoicePanel dashboard. The voice-recognition service remains independent. */
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val commandExecutor = Executors.newSingleThreadExecutor()

    private lateinit var dateView: TextView
    private lateinit var weekdayView: TextView
    private lateinit var headerVoiceStatus: TextView
    private lateinit var statusView: TextView
    private lateinit var resultView: TextView
    private lateinit var voiceDot: View
    private lateinit var waveView: VoiceWaveView
    private lateinit var voiceCardMain: TextView
    private lateinit var wifiMain: TextView
    private lateinit var wifiSub: TextView
    private lateinit var wifiHeaderDot: View
    private lateinit var wifiHeaderBox: LinearLayout
    private lateinit var wifiHeaderMainView: TextView
    private lateinit var wifiHeaderIpView: TextView
    private lateinit var controlPanelView: View
    private lateinit var controlToggleButton: View
    private val hideControlPanelRunnable = Runnable { hideControlPanel() }
    private lateinit var lampMain: TextView
    private lateinit var lampSub: TextView
    private lateinit var weatherTempView: TextView
    private lateinit var weatherCaptionView: TextView
    private lateinit var weatherIconContainer: FrameLayout
    private lateinit var alarmTimeHeaderView: TextView
    private lateinit var alarmDaysHeaderView: TextView
    private lateinit var alarmHeaderDot: View
    private lateinit var alarmHeaderBox: LinearLayout
    private lateinit var hourlyForecastContainer: LinearLayout
    private lateinit var hourlyForecastHint: TextView
    @Volatile private var weatherRequestRunning = false
    @Volatile private var weatherRefreshPending = false
    @Volatile private var weatherRequestLat = ""
    @Volatile private var weatherRequestLon = ""
    @Volatile private var lastWeatherRequestAt = 0L
    @Volatile private var lastGeocodeRequestAt = 0L
    private val weatherExecutor = Executors.newSingleThreadExecutor()
    private var receiverRegistered = false
    private var voiceRunning = false
    private var isWideLayout = true

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != LightVoiceService.ACTION_STATUS) return
            val status = intent.getStringExtra(LightVoiceService.EXTRA_STATUS)
            val last = intent.getStringExtra(LightVoiceService.EXTRA_LAST)
            if (!status.isNullOrBlank()) updateVoiceStatus(status)
            if (!last.isNullOrBlank()) {
                resultView.text = last
                resultView.visibility = View.VISIBLE
            }
        }
    }

    private val dateTick = object : Runnable {
        override fun run() {
            if (::dateView.isInitialized) {
                val now = Date()
                dateView.text = SimpleDateFormat("d MMMM yyyy", Locale("ru", "RU")).format(now)
                weekdayView.text = SimpleDateFormat("EEEE", Locale("ru", "RU")).format(now)
                    .uppercase(Locale("ru", "RU"))
            }
            if (::wifiHeaderDot.isInitialized) updateWifiStatus()
            if (::alarmTimeHeaderView.isInitialized) updateAlarmHeader()
            applyInterfaceBrightness()
            refreshWeather(false)
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 5, 6)
        window.navigationBarColor = Color.rgb(5, 5, 6)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyImmersiveMode()

        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        if (!prefs.contains("controller_base")) prefs.edit().putString("controller_base", "http://192.168.0.10").apply()
        if (!prefs.contains("controller_route")) prefs.edit().putString("controller_route", "/cmd?name={command}").apply()
        buildUi()
        dateTick.run()
        updateVoiceStatus(prefs.getString("voice_status", "Голосовой режим не запущен") ?: "Голосовой режим не запущен")
        resultView.text = prefs.getString("last_recognized", "Скажи «Шайтан батыр, включи свет»")
        updateWifiStatus()
        updateAlarmHeader()
        loadCachedWeather()
        applyInterfaceBrightness()
        refreshWeather(false)
    }

    private fun buildUi() {
        isWideLayout = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE &&
            resources.displayMetrics.widthPixels / resources.displayMetrics.density >= 760f

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(if (isWideLayout) 12 else 8), dp(if (isWideLayout) 6 else 5), dp(if (isWideLayout) 12 else 8), dp(5))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF050506.toInt(), 0xFF0D0D0F.toInt(), 0xFF050506.toInt())
            )
        }

        // Compact header: identity, current weather, Wi-Fi indicator, date, settings.
        root.addView(buildHeader(), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(if (isWideLayout) 62 else 56)
        ))

        // The clock receives all remaining vertical space. Light controls are an overlay,
        // not a permanently reserved right-hand column.
        root.addView(buildClockStage(), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (isWideLayout) 0 else dp(365),
            if (isWideLayout) 1f else 0f
        ).apply { topMargin = dp(5) })

        // Three large, readable forecast cards replace the old dense hourly strip.
        root.addView(buildHourlyForecastPanel(), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(if (isWideLayout) 164 else 156)
        ).apply { topMargin = dp(5); bottomMargin = dp(2) })

        // Keep this footer text exactly as in the approved design.
        root.addView(makeText("—  ШАЙТАН БАТЫР ВСЕГДА РЯДОМ  —", 12f, AMBER_MUTED).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(if (isWideLayout) 24 else 22)))

        if (isWideLayout) {
            setContentView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            val scroll = ScrollView(this).apply {
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
                setBackgroundColor(Color.BLACK)
                addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            setContentView(scroll)
        }
    }

    private fun buildHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(if (isWideLayout) 12 else 8), dp(3), dp(if (isWideLayout) 10 else 7), dp(3))
            background = roundedGradient(0xFF17191C.toInt(), 0xFF08090B.toInt(), 0xFF30343B.toInt(), dp(21).toFloat())
            elevation = dp(3).toFloat()
        }

        val homePlate = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = roundedGradient(0xFF24201D.toInt(), 0xFF111214.toInt(), 0xFF514032.toInt(), dp(15).toFloat())
        }
        homePlate.addView(PanelIconView(this, "home", TEXT_BRIGHT), LinearLayout.LayoutParams(dp(30), dp(30)))
        header.addView(homePlate, LinearLayout.LayoutParams(dp(if (isWideLayout) 44 else 40), dp(if (isWideLayout) 44 else 40)).apply {
            rightMargin = dp(if (isWideLayout) 10 else 7)
        })

        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        brand.addView(makeText("LightVoicePanel", if (isWideLayout) 21f else 17f, TEXT_BRIGHT).apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            includeFontPadding = false
        }, wrap())
        brand.addView(makeText("Умный дом. Голос. Свет.", if (isWideLayout) 10f else 9f, TEXT_MUTED).apply { maxLines = 1 }, wrap())
        header.addView(brand, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, if (isWideLayout) 0.98f else 0.74f))

        // Tappable lamp-alarm summary sits between the app title and current weather.
        alarmHeaderBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(if (isWideLayout) 6 else 3), dp(2), dp(if (isWideLayout) 7 else 3), dp(2))
            background = roundedGradient(0xFF211A14.toInt(), 0xFF111012.toInt(), 0xFF614126.toInt(), dp(12).toFloat())
            // Move the alarm summary about one physical centimetre left; use dp so this
            // remains visible on high-density tablet screens without changing header weights.
            translationX = -dp(60).toFloat()
            isClickable = true
            isFocusable = true
            contentDescription = "Будильник люстры: открыть настройки"
            setOnClickListener { showAlarmDialog() }
        }
        val alarmIconPlate = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF24190F.toInt())
                setStroke(dp(1), 0x665D4027)
            }
        }
        alarmIconPlate.addView(PanelIconView(this, "alarm", AMBER),
            FrameLayout.LayoutParams(dp(if (isWideLayout) 24 else 20), dp(if (isWideLayout) 24 else 20), Gravity.CENTER))
        alarmHeaderDot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF6B7078.toInt()); setStroke(dp(1), 0xFF0D0E10.toInt()) }
        }
        alarmIconPlate.addView(alarmHeaderDot, FrameLayout.LayoutParams(dp(7), dp(7), Gravity.RIGHT or Gravity.BOTTOM).apply {
            rightMargin = dp(1); bottomMargin = dp(1)
        })
        alarmHeaderBox.addView(alarmIconPlate, LinearLayout.LayoutParams(dp(if (isWideLayout) 30 else 25), dp(if (isWideLayout) 30 else 25)).apply {
            rightMargin = dp(if (isWideLayout) 13 else 8)
        })
        val alarmTextStack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        alarmTimeHeaderView = makeText("07:10", if (isWideLayout) 15f else 12f, AMBER).apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            includeFontPadding = false
        }
        alarmDaysHeaderView = makeText("ВЫКЛ", if (isWideLayout) 8f else 7f, TEXT_MUTED).apply {
            maxLines = 1
            includeFontPadding = false
        }
        alarmTextStack.addView(alarmTimeHeaderView, wrap())
        alarmTextStack.addView(alarmDaysHeaderView, wrap())
        alarmHeaderBox.addView(alarmTextStack, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(alarmHeaderBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, if (isWideLayout) 0.60f else 0.48f).apply {
            leftMargin = dp(if (isWideLayout) 4 else 2)
            rightMargin = dp(if (isWideLayout) 7 else 3)
        })

        val weather = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
                val lat = prefs.getString("weather_lat", "").orEmpty().trim()
                val lon = prefs.getString("weather_lon", "").orEmpty().trim()
                if (lat.isBlank() || lon.isBlank()) {
                    Toast.makeText(this@MainActivity, "Укажи место для прогноза в разделе «Настройки».", Toast.LENGTH_LONG).show()
                } else {
                    refreshWeather(true)
                    Toast.makeText(this@MainActivity, "Обновляю погоду…", Toast.LENGTH_SHORT).show()
                }
            }
        }
        weatherIconContainer = FrameLayout(this)
        weatherIconContainer.addView(PanelIconView(this, "cloudsun", 0xFFE5E7EA.toInt()),
            FrameLayout.LayoutParams(dp(if (isWideLayout) 34 else 28), dp(if (isWideLayout) 34 else 28), Gravity.CENTER))
        weather.addView(weatherIconContainer, LinearLayout.LayoutParams(dp(if (isWideLayout) 38 else 31), dp(if (isWideLayout) 38 else 31)).apply {
            rightMargin = dp(if (isWideLayout) 5 else 3)
        })
        val weatherText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        weatherTempView = makeText("—°", if (isWideLayout) 23f else 18f, TEXT_BRIGHT).apply { maxLines = 1; includeFontPadding = false }
        weatherCaptionView = makeText("ПОГОДА", if (isWideLayout) 9f else 8f, TEXT_MUTED).apply { letterSpacing = 0.01f; maxLines = 1 }
        weatherText.addView(weatherTempView, wrap())
        weatherText.addView(weatherCaptionView, wrap())
        weather.addView(weatherText, wrap())
        header.addView(weather, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, if (isWideLayout) 0.76f else 0.58f).apply {
            leftMargin = dp(if (isWideLayout) 6 else 3)
            rightMargin = dp(if (isWideLayout) 6 else 3)
        })

        // Wi-Fi/controller summary restored to the header: icon + lamp-online label + controller IP.
        wifiHeaderBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(if (isWideLayout) 6 else 3), dp(2), dp(if (isWideLayout) 8 else 4), dp(2))
            background = roundedGradient(0xFF171B20.toInt(), 0xFF0B0E12.toInt(), 0xFF303A45.toInt(), dp(12).toFloat())
            contentDescription = "Состояние Wi-Fi и контроллера люстры"
        }
        val wifiIconPlate = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF101820.toInt())
                setStroke(dp(1), 0x55303A45)
            }
        }
        wifiIconPlate.addView(PanelIconView(this, "wifi", 0xFF50B6FF.toInt()),
            FrameLayout.LayoutParams(dp(if (isWideLayout) 25 else 22), dp(if (isWideLayout) 25 else 22), Gravity.CENTER))
        wifiHeaderDot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF54CE6A.toInt()); setStroke(dp(1), 0xFF090A0B.toInt()) }
        }
        wifiIconPlate.addView(wifiHeaderDot, FrameLayout.LayoutParams(dp(8), dp(8), Gravity.RIGHT or Gravity.BOTTOM).apply {
            rightMargin = dp(2); bottomMargin = dp(2)
        })
        wifiHeaderBox.addView(wifiIconPlate, LinearLayout.LayoutParams(dp(if (isWideLayout) 34 else 30), dp(if (isWideLayout) 34 else 30)).apply {
            rightMargin = dp(if (isWideLayout) 6 else 4)
        })
        val wifiTextStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        wifiHeaderMainView = makeText("ЛЮСТРА ОНЛАЙН", if (isWideLayout) 10f else 8f, 0xFF54CE6A.toInt()).apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            includeFontPadding = false
        }
        wifiHeaderIpView = makeText("192.168.0.10", if (isWideLayout) 10f else 8f, TEXT_MUTED).apply {
            maxLines = 1
            includeFontPadding = false
        }
        wifiTextStack.addView(wifiHeaderMainView, wrap())
        wifiTextStack.addView(wifiHeaderIpView, wrap())
        wifiHeaderBox.addView(wifiTextStack, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(wifiHeaderBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, if (isWideLayout) 0.88f else 0.72f).apply {
            leftMargin = dp(if (isWideLayout) 4 else 2)
            rightMargin = dp(if (isWideLayout) 6 else 3)
        })

        val divider = View(this).apply { setBackgroundColor(0x66383C43) }
        header.addView(divider, LinearLayout.LayoutParams(dp(1), dp(if (isWideLayout) 36 else 31)).apply { rightMargin = dp(7) })

        val dateBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setPadding(dp(if (isWideLayout) 7 else 3), 0, dp(3), 0)
        }
        dateView = makeText("", if (isWideLayout) 12f else 9f, TEXT_BRIGHT).apply { gravity = Gravity.END; maxLines = 1 }
        weekdayView = makeText("", if (isWideLayout) 10f else 8f, TEXT_MUTED).apply { gravity = Gravity.END; maxLines = 1 }
        dateBox.addView(dateView, wrap())
        dateBox.addView(weekdayView, wrap())
        header.addView(dateBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, if (isWideLayout) 0.58f else 0.43f).apply { rightMargin = dp(5) })

        val settingsButton = FrameLayout(this).apply {
            background = roundedGradient(0xFF22252A.toInt(), 0xFF101216.toInt(), 0xFF373C45.toInt(), dp(12).toFloat())
            isClickable = true
            isFocusable = true
            contentDescription = "Настройки"
            setOnClickListener { showExtrasDialog() }
        }
        settingsButton.addView(PanelIconView(this, "settings", 0xFFD1D7E2.toInt()),
            FrameLayout.LayoutParams(dp(if (isWideLayout) 30 else 27), dp(if (isWideLayout) 30 else 27), Gravity.CENTER))
        header.addView(settingsButton, LinearLayout.LayoutParams(dp(if (isWideLayout) 44 else 40), dp(if (isWideLayout) 44 else 40)))
        return header
    }

    private fun buildClockStage(): View {
        val stage = FrameLayout(this).apply {
            background = roundedGradient(0xFF100B08.toInt(), 0xFF080809.toInt(), 0xFF34261E.toInt(), dp(18).toFloat())
            elevation = dp(2).toFloat()
            clipChildren = true
            clipToPadding = true
            clipToOutline = true
        }
        stage.addView(NixieClockView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        controlPanelView = buildControlPanel().apply {
            visibility = View.GONE
            alpha = 1f
            elevation = dp(14).toFloat()
        }
        val widthDp = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
        val panelWidth = if (isWideLayout) (widthDp * 0.38f).toInt().coerceIn(320, 480) else (widthDp * 0.88f).toInt().coerceAtLeast(280)
        stage.addView(controlPanelView, FrameLayout.LayoutParams(
            dp(panelWidth), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.RIGHT or Gravity.CENTER_VERTICAL
        ).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })

        controlToggleButton = buildControlToggleButton().apply { elevation = dp(16).toFloat() }
        stage.addView(controlToggleButton, FrameLayout.LayoutParams(dp(if (isWideLayout) 78 else 72), dp(if (isWideLayout) 54 else 50), Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(2)
        })
        return stage
    }

    private fun buildControlToggleButton(): View {
        val button = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(5), dp(7), dp(5))
            background = roundedGradient(0xFF342014.toInt(), 0xFF111013.toInt(), 0xFFB96B2F.toInt(), dp(15).toFloat())
            isClickable = true
            isFocusable = true
            contentDescription = "Открыть управление светом"
            setOnClickListener { showControlPanel() }
        }
        button.addView(PanelIconView(this, "bulb", AMBER), LinearLayout.LayoutParams(dp(27), dp(31)).apply { rightMargin = dp(3) })
        button.addView(makeText("СВЕТ", if (isWideLayout) 10f else 9f, TEXT_BRIGHT).apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
        }, wrap())
        return button
    }

    private fun showControlPanel() {
        if (!::controlPanelView.isInitialized || !::controlToggleButton.isInitialized) return
        handler.removeCallbacks(hideControlPanelRunnable)
        val panel = controlPanelView
        controlToggleButton.visibility = View.GONE
        panel.animate().cancel()
        panel.visibility = View.VISIBLE
        panel.alpha = 0f
        panel.post {
            panel.translationX = panel.width.toFloat().coerceAtLeast(dp(280).toFloat())
            panel.animate().translationX(0f).alpha(1f).setDuration(240L).start()
        }
        scheduleControlPanelAutoHide()
    }

    private fun scheduleControlPanelAutoHide() {
        handler.removeCallbacks(hideControlPanelRunnable)
        if (::controlPanelView.isInitialized && controlPanelView.visibility == View.VISIBLE) {
            handler.postDelayed(hideControlPanelRunnable, 10_000L)
        }
    }

    private fun hideControlPanel() {
        handler.removeCallbacks(hideControlPanelRunnable)
        if (!::controlPanelView.isInitialized || !::controlToggleButton.isInitialized) return
        val panel = controlPanelView
        if (panel.visibility != View.VISIBLE) {
            controlToggleButton.visibility = View.VISIBLE
            return
        }
        panel.animate().cancel()
        panel.animate().translationX(panel.width.toFloat().coerceAtLeast(dp(280).toFloat()))
            .alpha(0.98f).setDuration(180L).withEndAction {
                panel.visibility = View.GONE
                panel.translationX = 0f
                panel.alpha = 1f
                controlToggleButton.visibility = View.VISIBLE
            }.start()
    }

    private fun buildHourlyForecastPanel(): View {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(if (isWideLayout) 12 else 8), dp(5), dp(if (isWideLayout) 12 else 8), dp(7))
            background = roundedGradient(0xFF111317.toInt(), 0xFF090A0C.toInt(), 0xFF292C32.toInt(), dp(16).toFloat())
        }
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        heading.addView(makeText("ПРОГНОЗ ПОГОДЫ", if (isWideLayout) 14f else 11f, TEXT_MUTED).apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.07f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        hourlyForecastHint = makeText("ЧЕРЕЗ 3 · 6 · 9 ЧАСОВ", if (isWideLayout) 10f else 8f, AMBER_MUTED).apply { gravity = Gravity.END; maxLines = 1 }
        heading.addView(hourlyForecastHint, wrap())
        panel.addView(heading, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(20)))

        hourlyForecastContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, 0)
        }
        panel.addView(hourlyForecastContainer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        renderHourlyForecast(getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE).getString("weather_hourly", "").orEmpty())
        return panel
    }

    private fun buildControlPanel(): View {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (isWideLayout) Gravity.TOP else Gravity.NO_GRAVITY
            setPadding(dp(if (isWideLayout) 12 else 10), dp(if (isWideLayout) 10 else 10), dp(if (isWideLayout) 12 else 10), dp(8))
            background = roundedGradient(0xFF111419.toInt(), 0xFF07090C.toInt(), 0xFF30353D.toInt(), dp(22).toFloat())
            elevation = dp(3).toFloat()
        }
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        heading.addView(PanelIconView(this, "bulb", AMBER), LinearLayout.LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(7) })
        heading.addView(makeText("Управление светом", if (isWideLayout) 19f else 16f, TEXT_BRIGHT).apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val closeButton = makeText("×", if (isWideLayout) 30f else 27f, TEXT_MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(dp(6), 0, dp(2), dp(2))
            isClickable = true
            isFocusable = true
            contentDescription = "Закрыть управление светом"
            setOnClickListener { hideControlPanel() }
        }
        heading.addView(closeButton, LinearLayout.LayoutParams(dp(34), dp(34)))
        panel.addView(heading, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (isWideLayout) dp(38) else dp(32)))

        val resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        lampMain = makeText("Ожидает команды", if (isWideLayout) 11f else 10f, AMBER).apply { maxLines = 1 }
        lampSub = makeText("Локальный API", if (isWideLayout) 9f else 8f, TEXT_MUTED).apply { maxLines = 1 }
        resultBox.addView(lampMain, wrap())
        resultBox.addView(lampSub, wrap())
        panel.addView(resultBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(if (isWideLayout) 31 else 26)).apply { topMargin = dp(2) })

        // Keep service/status receivers working without restoring the removed lower status row.
        statusView = makeText("Скажите: «Шайтан батыр, …»", 10f, TEXT_MUTED).apply { visibility = View.GONE }
        resultView = makeText("", 10f, TEXT_MUTED).apply { visibility = View.GONE }

        panel.addView(View(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, if (isWideLayout) 0.25f else 0f))
        addControlRow(panel, 58, 1.10f, listOf(
            ControlItem("power", "Вкл/Выкл", listOf("power"), AMBER, true),
            ControlItem("moon", "Ночник", listOf("night", "warmer", "darker", "darker"), TEXT_BRIGHT, false)
        ))
        addControlRow(panel, 48, 1.00f, listOf(
            ControlItem("sun", "20%", listOf("20"), TEXT_BRIGHT),
            ControlItem("sun", "50%", listOf("50"), TEXT_BRIGHT),
            ControlItem("sun", "100%", listOf("100"), TEXT_BRIGHT)
        ))
        addControlRow(panel, 50, 0.95f, listOf(
            ControlItem("sunUp", "Ярче", listOf("brighter"), TEXT_BRIGHT),
            ControlItem("sunDown", "Темнее", listOf("darker"), TEXT_BRIGHT)
        ))
        addControlRow(panel, 51, 1.10f, listOf(
            ControlItem("thermometer", "3000K", listOf("3000"), 0xFFFFB34D.toInt()),
            ControlItem("thermometer", "4000K", listOf("4000"), TEXT_BRIGHT),
            ControlItem("thermometer", "6500K", listOf("6500"), 0xFF61CFFF.toInt())
        ))
        addControlRow(panel, 48, 0.85f, listOf(
            ControlItem("flame", "Теплее", listOf("warmer"), 0xFFFFB34D.toInt()),
            ControlItem("snowflake", "Холоднее", listOf("cooler"), 0xFF91D8F4.toInt())
        ))
        panel.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_DOWN) scheduleControlPanelAutoHide()
            false
        }
        return panel
    }

    private fun addControlRow(panel: LinearLayout, heightDp: Int, rowWeight: Float, items: List<ControlItem>) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val gap = dp(if (isWideLayout) 8 else 6)
        items.forEachIndexed { index, item ->
            val button = controlButton(item)
            row.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                if (index > 0) leftMargin = gap / 2
                if (index < items.lastIndex) rightMargin = gap / 2
            })
        }
        val params = if (isWideLayout) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, rowWeight)
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp))
        }
        params.topMargin = dp(if (isWideLayout) 7 else 4)
        panel.addView(row, params)
    }

    private fun controlButton(item: ControlItem): View {
        val primary = item.primary
        val button = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(if (isWideLayout) 4 else 6), dp(3), dp(if (isWideLayout) 3 else 5))
            background = roundedGradient(
                if (primary) 0xFF542A12.toInt() else 0xFF1A1D22.toInt(),
                if (primary) 0xFF24120B.toInt() else 0xFF0C0E11.toInt(),
                if (primary) 0xFFE17B2C.toInt() else 0xFF3D424B.toInt(),
                dp(18).toFloat()
            )
            isClickable = true
            isFocusable = true
            contentDescription = item.label
            setOnClickListener { sendLampCommands(item.commands, item.label); scheduleControlPanelAutoHide() }
        }
        button.addView(PanelIconView(this, item.icon, item.accent), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        button.addView(makeText(item.label, if (isWideLayout) 16f else 13f,
            if (primary) 0xFFFFE2C4.toInt() else if (item.accent != TEXT_BRIGHT) item.accent else TEXT_BRIGHT).apply {
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            includeFontPadding = false
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (isWideLayout) dp(28) else dp(22)))
        return button
    }

    private fun buildStatusStrip(wide: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        // The former lamp-status slot now carries the voice status that used to occupy
        // the header; the panel's control result remains visible in the first card.
        val lampCard = statusCard("", "Люстра", "Ожидает команды", AMBER).also {
            lampMain = it.second
            lampSub = it.third
            it.third.text = "Локальный API"
        }
        val wifiCard = statusCard("", "Wi-Fi", "Проверяю сеть…", 0xFF50B6FF.toInt()).also {
            wifiMain = it.second
            wifiSub = it.third
        }
        val voiceCard = buildVoiceStatusCard()
        val settings = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(if (isWideLayout) 8 else 14), dp(if (isWideLayout) 5 else 8), dp(if (isWideLayout) 8 else 14), dp(if (isWideLayout) 5 else 8))
            background = roundedGradient(0xFF17191D.toInt(), 0xFF101114.toInt(), 0xFF343841.toInt(), dp(30).toFloat())
            isClickable = true
            isFocusable = true
            setOnClickListener { showExtrasDialog() }
        }
        settings.addView(PanelIconView(this, "settings", 0xFFB9C1D3.toInt()), LinearLayout.LayoutParams(dp(if (isWideLayout) 30 else 38), dp(if (isWideLayout) 30 else 38)))
        settings.addView(makeText("Настройки", if (isWideLayout) 14f else 12f, 0xFFD1D5DF.toInt()).apply {
            setPadding(dp(12), 0, dp(8), 0)
        }, wrap())
        settings.addView(makeText("›", 29f, 0xFFB9C1D3.toInt()), wrap())

        if (wide) {
            row.addView(lampCard.first, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.95f).apply { rightMargin = dp(6) })
            row.addView(wifiCard.first, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.08f).apply { leftMargin = dp(3); rightMargin = dp(6) })
            row.addView(voiceCard, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.98f).apply { leftMargin = dp(3); rightMargin = dp(6) })
            row.addView(settings, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.95f).apply { leftMargin = dp(3) })
        } else {
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            top.addView(lampCard.first, LinearLayout.LayoutParams(0, dp(64), 1f).apply { rightMargin = dp(4); bottomMargin = dp(5) })
            top.addView(wifiCard.first, LinearLayout.LayoutParams(0, dp(64), 1f).apply { leftMargin = dp(4); bottomMargin = dp(5) })
            bottom.addView(voiceCard, LinearLayout.LayoutParams(0, dp(64), 1f).apply { rightMargin = dp(4) })
            bottom.addView(settings, LinearLayout.LayoutParams(0, dp(64), 1f).apply { leftMargin = dp(4) })
            row.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(bottom, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return row
    }

    private fun buildVoiceStatusCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(if (isWideLayout) 8 else 12), dp(if (isWideLayout) 5 else 9), dp(if (isWideLayout) 7 else 10), dp(if (isWideLayout) 5 else 8))
            background = roundedGradient(0xFF101113.toInt(), 0xFF080809.toInt(), 0xFF292B30.toInt(), dp(18).toFloat())
            isClickable = true
            isFocusable = true
            setOnClickListener { toggleVoiceListening() }
        }
        val iconPlate = FrameLayout(this)
        iconPlate.background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF17191D.toInt(), 0xFF0D0E10.toInt())).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(1), 0xFF24272D.toInt())
        }
        iconPlate.addView(PanelIconView(this, "mic", AMBER), FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER))
        card.addView(iconPlate, LinearLayout.LayoutParams(if (isWideLayout) dp(44) else dp(38), if (isWideLayout) dp(44) else dp(38)).apply { rightMargin = dp(10) })
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        texts.addView(makeText("Голосовое управление", if (isWideLayout) 13f else 11f, TEXT_MUTED).apply { maxLines = 1 }, wrap())
        voiceCardMain = makeText("Готов к команде", if (isWideLayout) 12f else 11f, 0xFF54CE6A.toInt()).apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); maxLines = 1
        }
        texts.addView(voiceCardMain, wrap())
        statusView = makeText("Скажите: «Шайтан батыр, …»", if (isWideLayout) 10f else 10f, TEXT_MUTED).apply { maxLines = 1 }
        texts.addView(statusView, wrap())
        resultView = makeText("", 10f, 0xFF8E94A5.toInt()).apply { maxLines = 1; visibility = View.GONE }
        texts.addView(resultView, wrap())
        card.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return card
    }

    /** Returns the card plus its main and sub labels so service/manual status can update them. */
    private fun statusCard(iconText: String, title: String, body: String, accent: Int): Triple<View, TextView, TextView> {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(if (isWideLayout) 8 else 12), dp(if (isWideLayout) 6 else 10), dp(if (isWideLayout) 7 else 10), dp(if (isWideLayout) 6 else 10))
            background = roundedGradient(0xFF101113.toInt(), 0xFF080809.toInt(), 0xFF292B30.toInt(), dp(18).toFloat())
        }
        val vectorName = when {
            title.contains("Wi-Fi") -> "wifi"
            title.contains("Люстра") -> "bulb"
            title.contains("Голос") -> "mic"
            title.contains("Панель") -> "home"
            else -> "leaf"
        }
        val icon = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF17191D.toInt(), 0xFF0D0E10.toInt())).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(1), 0xFF24272D.toInt())
            }
        }
        // Compose the icon as a vector on top of the glowing circular plate.
        val iconStack = android.widget.FrameLayout(this)
        iconStack.addView(icon, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        iconStack.addView(PanelIconView(this, vectorName, accent), android.widget.FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER))
        card.addView(iconStack, LinearLayout.LayoutParams(if (isWideLayout) dp(46) else dp(40), if (isWideLayout) dp(46) else dp(40)).apply { rightMargin = dp(12) })
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        texts.addView(makeText(title, if (isWideLayout) 13f else 11f, TEXT_MUTED), wrap())
        val main = makeText(body, if (isWideLayout) 13f else 12f, accent).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); maxLines = 1 }
        texts.addView(main, wrap())
        val sub = makeText("", if (isWideLayout) 10f else 10f, TEXT_MUTED).apply { maxLines = 1 }
        texts.addView(sub, wrap())
        card.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return Triple(card, main, sub)
    }

    private fun updateAlarmHeader() {
        if (!::alarmTimeHeaderView.isInitialized || !::alarmDaysHeaderView.isInitialized ||
            !::alarmHeaderDot.isInitialized || !::alarmHeaderBox.isInitialized) return
        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        val enabled = prefs.getBoolean("lamp_alarm_enabled", false)
        val hour = prefs.getInt("lamp_alarm_hour", 7).coerceIn(0, 23)
        val minute = prefs.getInt("lamp_alarm_minute", 10).coerceIn(0, 59)
        val mask = prefs.getInt("lamp_alarm_weekdays_mask", 0b00011111).and(0x7F)
        alarmTimeHeaderView.text = formatTimeOfDay(hour * 60 + minute)
        alarmTimeHeaderView.setTextColor(if (enabled) 0xFFFFB264.toInt() else 0xFF9B9DA4.toInt())
        alarmDaysHeaderView.text = if (enabled) formatAlarmDays(mask) else "ВЫКЛЮЧЕН"
        alarmDaysHeaderView.setTextColor(if (enabled) 0xFFB9A28D.toInt() else 0xFF777B83.toInt())
        alarmHeaderDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (enabled) 0xFF54CE6A.toInt() else 0xFF666A72.toInt())
            setStroke(dp(1), 0xFF0D0E10.toInt())
        }
        alarmHeaderBox.contentDescription = if (enabled) {
            "Будильник люстры включён в ${formatTimeOfDay(hour * 60 + minute)}, ${formatAlarmDays(mask)}. Открыть настройки"
        } else {
            "Будильник люстры выключен. Установленное время ${formatTimeOfDay(hour * 60 + minute)}. Открыть настройки"
        }
    }

    private fun formatAlarmDays(mask: Int): String {
        val normalized = mask and 0x7F
        if (normalized == 0b01111111) return "КАЖДЫЙ ДЕНЬ"
        if (normalized == 0b00011111) return "ПН–ПТ"
        if (normalized == ((1 shl 0) or (1 shl 2) or (1 shl 4))) return "ПН · СР · ПТ"
        val labels = listOf("ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС")
        val selected = labels.filterIndexed { index, _ -> (normalized and (1 shl index)) != 0 }
        if (selected.isEmpty()) return "ДНИ НЕ ВЫБРАНЫ"
        if (selected.size > 4) return "${selected.size} ДНЯ/НЕД"
        return selected.joinToString(" · ")
    }

    private fun showExtrasDialog() {
        AlertDialog.Builder(this)
            .setTitle("Настройки")
            .setItems(arrayOf(
                if (voiceRunning) "Остановить прослушивание" else "Запустить прослушивание",
                "Яркость, ночной режим, погода и ESP8266",
                "Будильник люстры"
            )) { _, which ->
                when (which) {
                    0 -> if (voiceRunning) stopListening() else requestMicAndStart()
                    1 -> showSettingsDialog()
                    2 -> showAlarmDialog()
                }
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun showSettingsDialog() {
        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            addView(panel, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        addSectionLabel(panel, "ЯРКОСТЬ ИНТЕРФЕЙСА")
        val dayBrightness = addBrightnessSlider(panel, "Яркость по умолчанию", prefs.getInt("panel_brightness_day", 100), 1, 100)

        val nightEnabled = CheckBox(this).apply {
            text = "Включать ночной режим по расписанию"
            setTextColor(TEXT_BRIGHT)
            textSize = 14f
            buttonTintList = android.content.res.ColorStateList.valueOf(AMBER)
            isChecked = prefs.getBoolean("panel_night_enabled", false)
        }
        panel.addView(nightEnabled, matchWrap().apply { topMargin = dp(10) })
        val nightBrightness = addBrightnessSlider(panel, "Яркость ночью", prefs.getInt("panel_brightness_night", 8), 1, 40)
        val nightStart = prefs.getInt("panel_night_start_minutes", 22 * 60 + 30).coerceIn(0, 1439)
        val nightEnd = prefs.getInt("panel_night_end_minutes", 7 * 60).coerceIn(0, 1439)
        val startTimeButton = settingActionButton("Начало ночного режима: ${formatTimeOfDay(nightStart)}")
        val endTimeButton = settingActionButton("Окончание ночного режима: ${formatTimeOfDay(nightEnd)}")
        var selectedNightStart = nightStart
        var selectedNightEnd = nightEnd
        startTimeButton.setOnClickListener {
            TimePickerDialog(this, { _, hour, minute ->
                selectedNightStart = hour * 60 + minute
                startTimeButton.text = "Начало ночного режима: ${formatTimeOfDay(selectedNightStart)}"
            }, selectedNightStart / 60, selectedNightStart % 60, true).show()
        }
        endTimeButton.setOnClickListener {
            TimePickerDialog(this, { _, hour, minute ->
                selectedNightEnd = hour * 60 + minute
                endTimeButton.text = "Окончание ночного режима: ${formatTimeOfDay(selectedNightEnd)}"
            }, selectedNightEnd / 60, selectedNightEnd % 60, true).show()
        }
        panel.addView(startTimeButton, matchWrap().apply { topMargin = dp(6) })
        panel.addView(endTimeButton, matchWrap().apply { topMargin = dp(5) })
        val nightInfo = makeText("Ночной режим затемняет только экран планшета, а не люстру. Если время начала и окончания совпадает, ночной режим не включается.", 11f, TEXT_MUTED)
        nightInfo.setPadding(0, dp(5), 0, dp(8))
        panel.addView(nightInfo, matchWrap())

        addSectionLabel(panel, "ПОГОДА · MET NORWAY")
        panel.addView(makeText("Введи название города/посёлка — приложение попробует найти координаты автоматически. Либо укажи широту и долготу вручную. Прогноз обновляется примерно раз в 30 минут и кэшируется.", 11f, TEXT_MUTED), matchWrap())
        val metAttribution = makeText("Данные прогноза: MET Norway · CC BY 4.0", 10f, TEXT_MUTED).apply {
            isClickable = true
            setOnClickListener { openAttributionUrl("https://api.met.no/doc/TermsOfService") }
        }
        panel.addView(metAttribution, matchWrap().apply { topMargin = dp(4) })
        val osmAttribution = makeText("Геокодирование: © OpenStreetMap contributors", 10f, TEXT_MUTED).apply {
            isClickable = true
            setOnClickListener { openAttributionUrl("https://www.openstreetmap.org/copyright") }
        }
        panel.addView(osmAttribution, matchWrap())
        val placeEdit = inputField(prefs.getString("weather_place", "") ?: "", "Название города или посёлка (необязательно)").apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        panel.addView(placeEdit, matchWrap().apply { topMargin = dp(5) })
        val latEdit = inputField(prefs.getString("weather_lat", "") ?: "", "Широта, например 55.75").apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        val lonEdit = inputField(prefs.getString("weather_lon", "") ?: "", "Долгота, например 37.62").apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        panel.addView(latEdit, matchWrap().apply { topMargin = dp(5) })
        panel.addView(lonEdit, matchWrap().apply { topMargin = dp(5); bottomMargin = dp(8) })

        addSectionLabel(panel, "ESP8266 · ЛЮСТРА")
        panel.addView(makeText("Адрес контроллера", 11f, TEXT_MUTED), wrap())
        val hostEdit = inputField(prefs.getString("controller_base", "http://192.168.0.10") ?: "http://192.168.0.10", "http://192.168.0.10")
        panel.addView(hostEdit, matchWrap().apply { topMargin = dp(4) })
        panel.addView(makeText("Путь HTTP-команды", 11f, TEXT_MUTED), wrap())
        val routeEdit = inputField(prefs.getString("controller_route", "/cmd?name={command}") ?: "/cmd?name={command}", "/cmd?name={command}")
        panel.addView(routeEdit, matchWrap().apply { topMargin = dp(4) })
        panel.addView(makeText("Плейсхолдер {command} заменяется на power, 20, warmer и другие команды.", 11f, TEXT_MUTED), wrap())

        val dialog = AlertDialog.Builder(this)
            .setTitle("Настройки панели")
            .setView(scroll)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить", null)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.78f).toInt(), (resources.displayMetrics.heightPixels * 0.86f).toInt())
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val host = hostEdit.text.toString().trim().trimEnd('/')
                var route = routeEdit.text.toString().trim()
                if (route.isBlank() || route == "/ir?code={code}") route = "/cmd?name={command}"
                val latText = latEdit.text.toString().trim().replace(',', '.')
                val lonText = lonEdit.text.toString().trim().replace(',', '.')
                val lat = latText.toDoubleOrNull()
                val lon = lonText.toDoubleOrNull()
                if ((latText.isBlank()) != (lonText.isBlank()) ||
                    (latText.isNotBlank() && (lat == null || lat !in -90.0..90.0 || lon == null || lon !in -180.0..180.0))) {
                    Toast.makeText(this, "Укажи обе координаты: широту от −90 до 90 и долготу от −180 до 180.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val oldLat = prefs.getString("weather_lat", "").orEmpty().trim().replace(',', '.')
                val oldLon = prefs.getString("weather_lon", "").orEmpty().trim().replace(',', '.')
                val oldPlace = prefs.getString("weather_place", "").orEmpty().trim()
                val selectedPlace = placeEdit.text.toString().trim()
                val coordinatesChanged = oldLat != latText || oldLon != lonText
                val resolveByName = selectedPlace.isNotBlank() &&
                    (latText.isBlank() && lonText.isBlank() || (selectedPlace != oldPlace && !coordinatesChanged))
                val savedLat = if (resolveByName) "" else latText
                val savedLon = if (resolveByName) "" else lonText
                val locationChanged = oldLat != savedLat || oldLon != savedLon || oldPlace != selectedPlace
                val weatherEditor = prefs.edit()
                    .putInt("panel_brightness_day", dayBrightness.progress + 1)
                    .putBoolean("panel_night_enabled", nightEnabled.isChecked)
                    .putInt("panel_brightness_night", nightBrightness.progress + 1)
                    .putInt("panel_night_start_minutes", selectedNightStart)
                    .putInt("panel_night_end_minutes", selectedNightEnd)
                    .putString("weather_place", selectedPlace)
                    .putString("weather_lat", savedLat)
                    .putString("weather_lon", savedLon)
                    .putString("controller_base", host)
                    .putString("controller_route", route)
                if (locationChanged) {
                    weatherEditor.remove("weather_temp")
                        .remove("weather_desc")
                        .remove("weather_symbol")
                        .remove("weather_hourly")
                        .remove("weather_updated_at")
                }
                weatherEditor.apply()
                hideKeyboard(hostEdit)
                applyInterfaceBrightness()
                updateWifiStatus()
                loadCachedWeather()
                dialog.dismiss()
                if (resolveByName) {
                    resolveWeatherPlace(selectedPlace)
                } else {
                    lastWeatherRequestAt = 0L
                    refreshWeather(true)
                }
            }
        }
        dialog.show()
    }

    private fun addSectionLabel(parent: LinearLayout, title: String) {
        val label = makeText(title, 11f, AMBER)
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.letterSpacing = 0.08f
        label.setPadding(0, dp(13), 0, dp(5))
        parent.addView(label, matchWrap())
    }

    private fun addBrightnessSlider(parent: LinearLayout, title: String, value: Int, minValue: Int, maxValue: Int): SeekBar {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleView = makeText(title, 13f, TEXT_BRIGHT)
        row.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val valueView = makeText("${value.coerceIn(minValue, maxValue)}%", 13f, AMBER).apply { gravity = Gravity.END }
        row.addView(valueView, LinearLayout.LayoutParams(dp(46), ViewGroup.LayoutParams.WRAP_CONTENT))
        parent.addView(row, matchWrap().apply { topMargin = dp(5) })
        val seek = SeekBar(this).apply {
            max = maxValue - minValue
            progress = value.coerceIn(minValue, maxValue) - minValue
            progressTintList = android.content.res.ColorStateList.valueOf(AMBER)
            thumbTintList = android.content.res.ColorStateList.valueOf(0xFFFFC078.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    valueView.text = "${progress + minValue}%"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        parent.addView(seek, matchWrap())
        return seek
    }

    private fun settingActionButton(label: String): TextView = makeText(label, 13f, TEXT_BRIGHT).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(11), dp(12), dp(11))
        background = roundedGradient(0xFF202125.toInt(), 0xFF111216.toInt(), 0xFF353941.toInt(), dp(10).toFloat())
        isClickable = true
        isFocusable = true
    }

    private fun showAlarmDialog() {
        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        var alarmHour = prefs.getInt("lamp_alarm_hour", 7).coerceIn(0, 23)
        var alarmMinute = prefs.getInt("lamp_alarm_minute", 10).coerceIn(0, 59)
        val defaultWeekdayMask = 0b00011111 // Monday through Friday
        var weekdayMask = prefs.getInt("lamp_alarm_weekdays_mask", defaultWeekdayMask).and(0x7F)

        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        val scroll = ScrollView(this).apply { addView(panel, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }
        val enabled = CheckBox(this).apply {
            text = "Будильник включён"
            textSize = 15f
            setTextColor(TEXT_BRIGHT)
            buttonTintList = android.content.res.ColorStateList.valueOf(AMBER)
            isChecked = prefs.getBoolean("lamp_alarm_enabled", false)
        }
        panel.addView(enabled, matchWrap())
        panel.addView(makeText("Повторять включение каждую неделю в выбранные дни.", 11f, TEXT_MUTED), matchWrap())

        panel.addView(makeText("ДНИ НЕДЕЛИ", 11f, TEXT_MUTED).apply { setPadding(0, dp(10), 0, dp(2)) }, matchWrap())
        val days = listOf(
            Calendar.MONDAY to "Пн", Calendar.TUESDAY to "Вт", Calendar.WEDNESDAY to "Ср",
            Calendar.THURSDAY to "Чт", Calendar.FRIDAY to "Пт", Calendar.SATURDAY to "Сб", Calendar.SUNDAY to "Вс"
        )
        val dayChecks = linkedMapOf<Int, CheckBox>()
        val daysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun applyMaskToChecks(mask: Int) {
            days.forEachIndexed { index, (day, _) -> dayChecks[day]?.isChecked = (mask and (1 shl index)) != 0 }
        }
        days.forEachIndexed { index, (day, label) ->
            val check = CheckBox(this).apply {
                text = label
                textSize = 11f
                setTextColor(TEXT_BRIGHT)
                buttonTintList = android.content.res.ColorStateList.valueOf(AMBER)
                isChecked = (weekdayMask and (1 shl index)) != 0
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, 0)
                minWidth = 0
            }
            dayChecks[day] = check
            daysRow.addView(check, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        panel.addView(daysRow, matchWrap())

        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun presetButton(title: String, mask: Int) = settingActionButton(title).apply {
            textSize = 11f
            gravity = Gravity.CENTER
            setOnClickListener { weekdayMask = mask; applyMaskToChecks(mask) }
        }
        presets.addView(presetButton("Будни", 0b00011111), LinearLayout.LayoutParams(0, dp(38), 1f).apply { rightMargin = dp(4) })
        presets.addView(presetButton("Пн/Ср/Пт", (1 shl 0) or (1 shl 2) or (1 shl 4)), LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        presets.addView(presetButton("Все дни", 0b01111111), LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(4) })
        panel.addView(presets, matchWrap().apply { topMargin = dp(4) })

        val timeButton = settingActionButton("Время включения: ${formatTimeOfDay(alarmHour * 60 + alarmMinute)}")
        timeButton.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                alarmHour = h; alarmMinute = m
                timeButton.text = "Время включения: ${formatTimeOfDay(alarmHour * 60 + alarmMinute)}"
            }, alarmHour, alarmMinute, true).show()
        }
        panel.addView(timeButton, matchWrap().apply { topMargin = dp(9) })
        panel.addView(makeText("Режим люстры при срабатывании", 12f, TEXT_MUTED).apply { setPadding(0, dp(12), 0, dp(4)) }, matchWrap())
        val modeLabels = arrayOf("Яркость 20%", "Яркость 50%", "Яркость 100%", "Ночник (Ночник → Теплее → Темнее → Темнее)", "Тёплый свет 3000 K", "Нейтральный свет 4000 K", "Холодный свет 6500 K", "Теплее", "Холоднее")
        val modeValues = arrayOf("20", "50", "100", "night", "3000", "4000", "6500", "warmer", "cooler")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modeLabels)
        val savedMode = prefs.getString("lamp_alarm_mode", "100") ?: "100"
        spinner.setSelection(modeValues.indexOf(savedMode).coerceAtLeast(0))
        panel.addView(spinner, matchWrap())
        panel.addView(makeText("Будильник срабатывает по выбранным дням каждую неделю. Для надёжной работы оставь планшет подключённым к питанию и домашнему Wi-Fi.", 11f, TEXT_MUTED).apply { setPadding(0, dp(8), 0, dp(4)) }, matchWrap())
        val lastResult = prefs.getString("lamp_alarm_last_result", "").orEmpty()
        if (lastResult.isNotBlank()) {
            panel.addView(makeText("Последнее срабатывание: $lastResult", 11f, TEXT_MUTED).apply { setPadding(0, dp(6), 0, 0) }, matchWrap())
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Еженедельный будильник люстры")
            .setView(scroll)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить", null)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.78f).toInt(), (resources.displayMetrics.heightPixels * 0.84f).toInt())
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                weekdayMask = 0
                days.forEachIndexed { index, (day, _) -> if (dayChecks[day]?.isChecked == true) weekdayMask = weekdayMask or (1 shl index) }
                if (enabled.isChecked && weekdayMask == 0) {
                    Toast.makeText(this, "Выбери хотя бы один день недели.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                prefs.edit()
                    .putBoolean("lamp_alarm_enabled", enabled.isChecked)
                    .putInt("lamp_alarm_weekdays_mask", weekdayMask)
                    .putInt("lamp_alarm_hour", alarmHour)
                    .putInt("lamp_alarm_minute", alarmMinute)
                    .putString("lamp_alarm_mode", modeValues[spinner.selectedItemPosition.coerceIn(modeValues.indices)])
                    .remove("lamp_alarm_start_date")
                    .remove("lamp_alarm_end_date")
                    .apply()
                updateAlarmHeader()
                if (enabled.isChecked) {
                    LampAlarmScheduler.scheduleNext(this)
                    val nextAt = prefs.getLong("lamp_alarm_next_at", 0L)
                    if (nextAt > 0L) Toast.makeText(this, "Будильник сохранён: ${SimpleDateFormat("EEE, HH:mm", Locale("ru", "RU")).format(Date(nextAt))}", Toast.LENGTH_LONG).show()
                    else Toast.makeText(this, "Не удалось запланировать следующее срабатывание.", Toast.LENGTH_LONG).show()
                } else {
                    LampAlarmScheduler.cancel(this)
                    prefs.edit().remove("lamp_alarm_next_at").apply()
                    Toast.makeText(this, "Будильник выключен.", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun formatTimeOfDay(minutes: Int): String = String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60)

    private fun applyInterfaceBrightness() {
        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        val day = prefs.getInt("panel_brightness_day", 100).coerceIn(1, 100)
        val night = prefs.getInt("panel_brightness_night", 8).coerceIn(1, 40)
        val nightEnabled = prefs.getBoolean("panel_night_enabled", false)
        val start = prefs.getInt("panel_night_start_minutes", 22 * 60 + 30).coerceIn(0, 1439)
        val end = prefs.getInt("panel_night_end_minutes", 7 * 60).coerceIn(0, 1439)
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val insideNightWindow = if (start < end) now >= start && now < end else now >= start || now < end
        val inNight = nightEnabled && start != end && insideNightWindow
        val brightness = if (inNight) night else day
        val params = window.attributes
        params.screenBrightness = (brightness / 100f).coerceIn(0.01f, 1f)
        window.attributes = params
    }

    private fun loadCachedWeather() {
        if (!::weatherTempView.isInitialized) return
        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        if (::hourlyForecastContainer.isInitialized) renderHourlyForecast(prefs.getString("weather_hourly", "").orEmpty())
        val temp = prefs.getString("weather_temp", "").orEmpty()
        val desc = prefs.getString("weather_desc", "").orEmpty()
        val symbol = prefs.getString("weather_symbol", "").orEmpty()
        if (temp.isNotBlank()) {
            updateWeatherUi(temp, desc.ifBlank { "ПОГОДА" }, symbol)
        } else {
            weatherTempView.text = "—°"
            weatherCaptionView.text = if (prefs.getString("weather_lat", "").orEmpty().isBlank()) "НАСТРОЙ КООРДИНАТЫ" else "ЗАГРУЗКА ПОГОДЫ…"
            setWeatherIcon("cloudsun")
        }
    }

    /** Resolve a human-readable home town once, then use fixed coordinates for weather requests. */
    private fun resolveWeatherPlace(place: String) {
        weatherCaptionView.text = "ИЩУ МЕСТО…"
        weatherExecutor.execute {
            try {
                val elapsed = System.currentTimeMillis() - lastGeocodeRequestAt
                if (elapsed < 1_100L) Thread.sleep(1_100L - elapsed)
                lastGeocodeRequestAt = System.currentTimeMillis()
                val q = URLEncoder.encode(place, "UTF-8")
                val url = URL("https://nominatim.openstreetmap.org/search?q=$q&format=json&limit=1")
                val connection = url.openConnection() as HttpURLConnection
                val payload = try {
                    connection.connectTimeout = 9000
                    connection.readTimeout = 9000
                    connection.requestMethod = "GET"
                    connection.setRequestProperty("User-Agent", "LightVoicePanel/0.6 (Android home dashboard)")
                    connection.setRequestProperty("Accept", "application/json")
                    connection.connect()
                    val code = connection.responseCode
                    if (code !in 200..299) throw IOException("поиск места: HTTP $code")
                    connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                } finally { connection.disconnect() }
                val results = org.json.JSONArray(payload)
                if (results.length() == 0) throw IOException("место не найдено")
                val item = results.getJSONObject(0)
                val lat = item.getString("lat").toDouble()
                val lon = item.getString("lon").toDouble()
                val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
                // Avoid overwriting a location the user changed while lookup was in flight.
                if (prefs.getString("weather_place", "").orEmpty().trim() != place) return@execute
                prefs.edit()
                    .putString("weather_lat", String.format(Locale.US, "%.6f", lat))
                    .putString("weather_lon", String.format(Locale.US, "%.6f", lon))
                    .remove("weather_temp")
                    .remove("weather_desc")
                    .remove("weather_symbol")
                    .remove("weather_hourly")
                    .remove("weather_updated_at")
                    .apply()
                handler.post {
                    lastWeatherRequestAt = 0L
                    weatherTempView.text = "—°"
                    weatherCaptionView.text = "ЗАГРУЖАЮ ПРОГНОЗ…"
                    refreshWeather(true)
                }
            } catch (e: Exception) {
                handler.post {
                    weatherTempView.text = "—°"
                    weatherCaptionView.text = "НЕ НАШЁЛ МЕСТО · УКАЖИ КООРДИНАТЫ"
                    Toast.makeText(this, "Не удалось найти место. Проверь название или введи координаты вручную.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun refreshWeather(force: Boolean) {
        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        val latText = prefs.getString("weather_lat", "").orEmpty().trim().replace(',', '.')
        val lonText = prefs.getString("weather_lon", "").orEmpty().trim().replace(',', '.')
        val lat = latText.toDoubleOrNull()
        val lon = lonText.toDoubleOrNull()
        if (lat == null || lon == null || lat !in -90.0..90.0 || lon !in -180.0..180.0) {
            if (::weatherTempView.isInitialized && prefs.getString("weather_temp", "").orEmpty().isBlank()) {
                weatherTempView.text = "—°"
                weatherCaptionView.text = "НАСТРОЙ КООРДИНАТЫ"
            }
            return
        }
        val cachedAt = prefs.getLong("weather_updated_at", 0L)
        val now = System.currentTimeMillis()
        if (!force && (now - cachedAt) < WEATHER_REFRESH_MS) return
        if (weatherRequestRunning) {
            if (weatherRequestLat != latText || weatherRequestLon != lonText) weatherRefreshPending = true
            return
        }
        // Keep failed requests from retrying every minute; manual refreshes are rate-limited to 60 seconds.
        val minimumRequestInterval = if (force) 60_000L else WEATHER_REFRESH_MS
        if (now - lastWeatherRequestAt < minimumRequestInterval) return
        weatherRequestRunning = true
        weatherRequestLat = latText
        weatherRequestLon = lonText
        lastWeatherRequestAt = now
        weatherExecutor.execute {
            try {
                val url = URL("https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=${String.format(Locale.US, "%.5f", lat)}&lon=${String.format(Locale.US, "%.5f", lon)}")
                val connection = url.openConnection() as HttpURLConnection
                val payload = try {
                    connection.connectTimeout = 9000
                    connection.readTimeout = 9000
                    connection.requestMethod = "GET"
                    connection.setRequestProperty("User-Agent", "LightVoicePanel/0.6 (Android home dashboard)")
                    connection.setRequestProperty("Accept", "application/json")
                    connection.useCaches = true
                    connection.connect()
                    val code = connection.responseCode
                    if (code !in 200..299) throw IOException("MET Norway HTTP $code")
                    connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                } finally { connection.disconnect() }
                val root = JSONObject(payload)
                val series = root.getJSONObject("properties").getJSONArray("timeseries")
                if (series.length() == 0) throw IOException("прогноз не содержит временных точек")
                val first = series.getJSONObject(0).getJSONObject("data")
                val temp = first.getJSONObject("instant").getJSONObject("details").getDouble("air_temperature")
                val next = first.optJSONObject("next_1_hours") ?: first.optJSONObject("next_6_hours")
                val symbol = next?.optJSONObject("summary")?.optString("symbol_code", "").orEmpty()
                val desc = describeWeather(symbol)
                val tempText = (if (temp > 0) "+" else "") + Math.round(temp).toString() + "°"

                val hourly = org.json.JSONArray()
                val minimumForecastTime = System.currentTimeMillis() - 30L * 60L * 1000L
                for (index in 0 until series.length()) {
                    if (hourly.length() >= 10) break
                    val item = series.getJSONObject(index)
                    val epoch = parseMetTime(item.optString("time", "")) ?: continue
                    if (epoch < minimumForecastTime) continue
                    val data = item.optJSONObject("data") ?: continue
                    val instant = data.optJSONObject("instant")?.optJSONObject("details") ?: continue
                    if (!instant.has("air_temperature")) continue
                    val nextHour = data.optJSONObject("next_1_hours") ?: data.optJSONObject("next_6_hours")
                    val symbolCode = nextHour?.optJSONObject("summary")?.optString("symbol_code", "").orEmpty()
                    val precipitation = nextHour?.optJSONObject("details")?.optDouble("precipitation_amount", 0.0) ?: 0.0
                    hourly.put(JSONObject()
                        .put("time", epoch)
                        .put("temp", Math.round(instant.getDouble("air_temperature")))
                        .put("symbol", symbolCode)
                        .put("precip", precipitation))
                }
                val hourlyJson = hourly.toString()
                val currentLat = prefs.getString("weather_lat", "").orEmpty().trim().replace(',', '.')
                val currentLon = prefs.getString("weather_lon", "").orEmpty().trim().replace(',', '.')
                if (currentLat != latText || currentLon != lonText) {
                    weatherRefreshPending = true
                    return@execute
                }
                prefs.edit()
                    .putString("weather_temp", tempText)
                    .putString("weather_desc", desc)
                    .putString("weather_symbol", symbol)
                    .putString("weather_hourly", hourlyJson)
                    .putLong("weather_updated_at", System.currentTimeMillis())
                    .apply()
                handler.post { updateWeatherUi(tempText, desc, symbol) }
            } catch (e: Exception) {
                handler.post {
                    if (prefs.getString("weather_temp", "").orEmpty().isBlank()) {
                        weatherTempView.text = "—°"
                        weatherCaptionView.text = when {
                            e.message?.contains("403") == true -> "СЕРВИС ПОГОДЫ ОТКЛОНИЛ ЗАПРОС"
                            !isNetworkConnected() -> "НЕТ ИНТЕРНЕТА"
                            else -> "ПОГОДА НЕДОСТУПНА"
                        }
                    } else {
                        weatherCaptionView.text = (prefs.getString("weather_desc", "ПОГОДА") ?: "ПОГОДА") + " · КЭШ"
                    }
                }
            } finally {
                weatherRequestRunning = false
                if (weatherRefreshPending) {
                    weatherRefreshPending = false
                    handler.post {
                        lastWeatherRequestAt = 0L
                        refreshWeather(true)
                    }
                }
            }
        }
    }

    private fun parseMetTime(value: String): Long? {
        return try {
            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            parser.timeZone = TimeZone.getTimeZone("UTC")
            parser.isLenient = false
            parser.parse(value)?.time
        } catch (_: Exception) { null }
    }

    private fun renderHourlyForecast(serialized: String) {
        if (!::hourlyForecastContainer.isInitialized) return
        hourlyForecastContainer.removeAllViews()
        val data = try { org.json.JSONArray(serialized) } catch (_: Exception) { org.json.JSONArray() }
        val now = System.currentTimeMillis()
        val entries = (0 until data.length()).mapNotNull { data.optJSONObject(it) }
            .filter { it.optLong("time", 0L) > 0L }
        hourlyForecastHint.text = if (entries.isEmpty()) "ОЖИДАЕТСЯ ОБНОВЛЕНИЕ" else "ЧЕРЕЗ 3 · 6 · 9 ЧАСОВ"

        val offsets = listOf(3, 6, 9)
        for ((slotIndex, hours) in offsets.withIndex()) {
            val target = now + hours * 60L * 60L * 1000L
            val item = entries.minByOrNull { kotlin.math.abs(it.optLong("time", target) - target) }
            val timestamp = item?.optLong("time", 0L) ?: 0L
            val temp = item?.optInt("temp", Int.MIN_VALUE) ?: Int.MIN_VALUE
            val symbol = item?.optString("symbol", "").orEmpty()
            val precip = item?.optDouble("precip", 0.0) ?: 0.0
            val forecastCalendar = Calendar.getInstance().apply { if (timestamp > 0L) timeInMillis = timestamp }
            val clockLabel = if (timestamp > 0L) {
                String.format(Locale.US, "%02d:%02d", forecastCalendar.get(Calendar.HOUR_OF_DAY), forecastCalendar.get(Calendar.MINUTE))
            } else "—:—"
            val code = symbol.toLowerCase(Locale.US)
            val iconName = when {
                code.contains("snow") || code.contains("sleet") -> "snow"
                code.contains("rain") || code.contains("drizzle") || code.contains("thunder") -> "rain"
                code.contains("fog") -> "fog"
                code.contains("clearsky") || code.contains("fair") -> "sun"
                code.contains("cloud") -> "cloudsun"
                else -> "cloudsun"
            }
            val accent = when (iconName) { "sun" -> AMBER; "rain", "snow" -> 0xFF75C9FF.toInt(); else -> TEXT_BRIGHT }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(if (isWideLayout) 12 else 8), dp(if (isWideLayout) 8 else 6), dp(if (isWideLayout) 12 else 8), dp(if (isWideLayout) 8 else 6))
                background = roundedGradient(
                    if (slotIndex == 0) 0xFF292016.toInt() else 0xFF191B20.toInt(),
                    0xFF0D0F12.toInt(),
                    if (slotIndex == 0) 0xFF654122.toInt() else 0xFF2A2E35.toInt(), dp(13).toFloat()
                )
            }
            val topLine = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val offsetLabel = if (hours == 3) "+3 ЧАСА" else "+$hours ЧАСОВ"
            topLine.addView(makeText(offsetLabel, if (isWideLayout) 20f else 16f, if (slotIndex == 0) AMBER else TEXT_MUTED).apply {
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); maxLines = 1; includeFontPadding = false
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            topLine.addView(makeText(clockLabel, if (isWideLayout) 18f else 14f, TEXT_MUTED).apply {
                gravity = Gravity.END; maxLines = 1; includeFontPadding = false
            }, wrap())
            card.addView(topLine, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

            // Keep the forecast offset label at the upper left and the clock time at
            // the upper right. The visual centre is reserved for the weather icon + temperature.
            val mainLine = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            // Weather glyph and temperature are the main information, so scale both up ~30%.
            // Keep the spacing in proportion and centre the pair as a single visual group.
            val iconSize = dp(if (isWideLayout) 114 else 88)
            mainLine.addView(PanelIconView(this, iconName, accent), LinearLayout.LayoutParams(iconSize, iconSize).apply {
                rightMargin = dp(if (isWideLayout) 18 else 10)
            })
            val valueStack = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL or Gravity.START
            }
            valueStack.addView(makeText(
                if (temp == Int.MIN_VALUE) "—°" else (if (temp > 0) "+" else "") + temp + "°",
                if (isWideLayout) 70f else 55f, TEXT_BRIGHT
            ).apply {
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                maxLines = 1
                includeFontPadding = false
            }, wrap())
            val rainText = if (precip >= 0.1) String.format(Locale.US, "%.1f мм осадков", precip) else ""
            if (rainText.isNotEmpty()) {
                valueStack.addView(makeText(rainText, if (isWideLayout) 15f else 12f, 0xFF75C9FF.toInt()).apply {
                    maxLines = 1; includeFontPadding = false
                }, wrap())
            }
            mainLine.addView(valueStack, wrap())
            card.addView(mainLine, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(2) })

            hourlyForecastContainer.addView(card, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                if (slotIndex > 0) leftMargin = dp(6)
            })
        }
    }

    private fun updateWeatherUi(temp: String, description: String, symbol: String) {
        if (!::weatherTempView.isInitialized) return
        weatherTempView.text = temp
        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        val place = prefs.getString("weather_place", "").orEmpty().trim()
        weatherCaptionView.text = (if (place.isBlank()) description else "$description · $place").uppercase(Locale("ru", "RU")).take(30)
        if (::hourlyForecastContainer.isInitialized) renderHourlyForecast(prefs.getString("weather_hourly", "").orEmpty())
        val code = symbol.toLowerCase(Locale.US)
        val icon = when {
            code.contains("snow") -> "snow"
            code.contains("rain") || code.contains("sleet") || code.contains("drizzle") -> "rain"
            code.contains("fog") -> "fog"
            code.contains("cloudy") -> "cloudsun"
            code.contains("clearsky") || code.contains("fair") -> "sun"
            else -> "cloudsun"
        }
        setWeatherIcon(icon)
    }

    private fun setWeatherIcon(name: String) {
        if (!::weatherIconContainer.isInitialized) return
        val color = when (name) { "sun" -> AMBER; "rain", "snow" -> 0xFF75C9FF.toInt(); else -> 0xFFE5E7EA.toInt() }
        weatherIconContainer.removeAllViews()
        weatherIconContainer.addView(PanelIconView(this, name, color), FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
    }

    private fun describeWeather(symbol: String): String {
        val code = symbol.toLowerCase(Locale.US)
        return when {
            code.contains("thunderstorm") -> "ГРОЗА"
            code.contains("heavyrain") -> "СИЛЬНЫЙ ДОЖДЬ"
            code.contains("rain") || code.contains("drizzle") -> "ДОЖДЬ"
            code.contains("sleet") -> "МОКРЫЙ СНЕГ"
            code.contains("heavysnow") -> "СИЛЬНЫЙ СНЕГ"
            code.contains("snow") -> "СНЕГ"
            code.contains("fog") -> "ТУМАН"
            code.contains("partlycloudy") -> "ПЕРЕМЕННАЯ ОБЛАЧНОСТЬ"
            code.contains("cloudy") -> "ОБЛАЧНО"
            code.contains("fair") -> "МАЛО ОБЛАЧНО"
            code.contains("clearsky") -> "ЯСНО"
            else -> "ПОГОДА"
        }
    }

    private fun isNetworkConnected(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val info = cm.activeNetworkInfo
            info != null && info.isConnected
        } catch (_: Exception) { false }
    }

    private fun openAttributionUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось открыть ссылку.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun inputField(value: String, hintValue: String): EditText = EditText(this).apply {
        setText(value)
        hint = hintValue
        textSize = 15f
        setTextColor(Color.WHITE)
        setHintTextColor(0xFF77716B.toInt())
        setSingleLine(true)
        setPadding(dp(14), dp(9), dp(14), dp(9))
        inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF805A38.toInt())
    }

    private fun toggleVoiceListening() {
        if (voiceRunning) stopListening() else requestMicAndStart()
    }

    private fun requestMicAndStart() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_RECORD_AUDIO)
            return
        }
        startListening()
    }

    private fun startListening() {
        val intent = Intent(this, LightVoiceService::class.java).setAction(LightVoiceService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        voiceRunning = true
        updateVoiceStatus("Запускаю офлайн-голосовой движок…")
    }

    private fun stopListening() {
        val stop = Intent(this, LightVoiceService::class.java).setAction(LightVoiceService.ACTION_STOP)
        startService(stop)
        voiceRunning = false
        updateVoiceStatus("Прослушивание остановлено")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_RECORD_AUDIO && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == REQUEST_RECORD_AUDIO) {
            updateVoiceStatus("Нужно разрешить доступ к микрофону")
        }
    }

    private fun updateVoiceStatus(status: String) {
        val lower = status.toLowerCase(Locale("ru", "RU"))
        statusView.text = when {
            lower.contains("ошибка") -> status
            lower.contains("останов") || lower.contains("не запущ") -> "Голосовое управление остановлено"
            lower.contains("слуш") || lower.contains("жду команд") || lower.contains("ключевую фразу") -> "Скажите: «Шайтан батыр, …»"
            lower.contains("выполня") || lower.contains("распозн") -> "Обрабатываю голосовую команду…"
            lower.contains("загружа") || lower.contains("модель") || lower.contains("подготов") -> "Подготавливаю голосовой модуль…"
            else -> status
        }

        if (lower.contains("останов") || lower.contains("не запущ") || lower.contains("нужно разрешить") || lower.contains("ошибка")) {
            voiceRunning = false
        } else if (lower.contains("слуш") || lower.contains("жду команд") || lower.contains("подготов") ||
            lower.contains("загружа") || lower.contains("выполня") || lower.contains("говори") || lower.contains("модель")) {
            voiceRunning = true
        }
        val simple = when {
            lower.contains("ошибка") -> "Ошибка"
            lower.contains("останов") || lower.contains("не запущ") -> "Остановлено"
            lower.contains("подготов") || lower.contains("загружа") || lower.contains("скачива") -> "Подготовка"
            lower.contains("выполня") -> "Выполняю…"
            lower.contains("жду команд") || lower.contains("говори") -> "Жду команду"
            lower.contains("слуш") -> "Слушаю…"
            lower.contains("готов") -> "Готов"
            else -> "Голосовой модуль"
        }
        if (::headerVoiceStatus.isInitialized) headerVoiceStatus.text = simple
        if (::voiceDot.isInitialized) {
            val dotColor = when {
                lower.contains("ошибка") -> 0xFFFF5C55.toInt()
                voiceRunning -> AMBER
                else -> 0xFF666A73.toInt()
            }
            (voiceDot.background as? GradientDrawable)?.setColor(dotColor)
        }
        if (::waveView.isInitialized) waveView.setActive(voiceRunning)
        if (::voiceCardMain.isInitialized) {
            voiceCardMain.text = when {
                lower.contains("ошибка") -> "Проверь микрофон"
                lower.contains("выполня") -> "Выполняю команду…"
                lower.contains("подготов") || lower.contains("загружа") -> "Подготовка…"
                voiceRunning -> "Слушаю ключевую фразу"
                else -> "Остановлено"
            }
            voiceCardMain.setTextColor(if (lower.contains("ошибка")) 0xFFFF5C55.toInt() else if (voiceRunning) 0xFF54CE6A.toInt() else TEXT_MUTED)
        }
    }

    private fun updateWifiStatus() {
        if (!::wifiHeaderDot.isInitialized) return
        val connected = try {
            val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val info = manager.activeNetworkInfo
            info != null && info.isConnected && info.type == ConnectivityManager.TYPE_WIFI
        } catch (_: Exception) { false }
        val dotColor = if (connected) 0xFF54CE6A.toInt() else 0xFFFF625B.toInt()
        wifiHeaderDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(dotColor)
            setStroke(dp(1), 0xFF090A0B.toInt())
        }
        if (::wifiHeaderMainView.isInitialized) {
            wifiHeaderMainView.text = if (connected) "ЛЮСТРА ОНЛАЙН" else "НЕТ WI-FI"
            wifiHeaderMainView.setTextColor(if (connected) 0xFF54CE6A.toInt() else 0xFFFF625B.toInt())
        }
        if (::wifiHeaderIpView.isInitialized) {
            val controllerBase = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
                .getString("controller_base", "http://192.168.0.10") ?: "http://192.168.0.10"
            val host = try {
                Uri.parse(controllerBase.trim()).host?.takeIf { it.isNotBlank() }
                    ?: controllerBase.trim().removePrefix("http://").removePrefix("https://").substringBefore('/').substringBefore(':')
            } catch (_: Exception) { "192.168.0.10" }
            wifiHeaderIpView.text = host
        }
        val address = if (::wifiHeaderIpView.isInitialized) wifiHeaderIpView.text.toString() else "192.168.0.10"
        wifiHeaderBox.contentDescription = if (connected) "Люстра онлайн. Адрес $address" else "Wi-Fi не подключён. Адрес контроллера $address"
    }

    private fun sendLampCommands(commands: List<String>, label: String) {
        if (commands.isEmpty()) return
        lampMain.text = "Отправляю…"
        lampMain.setTextColor(AMBER)
        lampSub.text = label
        commandExecutor.execute {
            try {
                for ((index, command) in commands.withIndex()) {
                    val response = sendControllerCommand(command)
                    if (response !in 200..299) {
                        handler.post {
                            lampMain.text = "HTTP $response"
                            lampMain.setTextColor(0xFFFF827A.toInt())
                            lampSub.text = "Команда: $command"
                        }
                        return@execute
                    }
                    if (commands.size > 1 && index < commands.lastIndex) Thread.sleep(320L)
                }
                handler.post {
                    lampMain.text = "Онлайн"
                    lampMain.setTextColor(0xFF54CE6A.toInt())
                    lampSub.text = "Выполнено: $label"
                }
            } catch (e: Exception) {
                handler.post {
                    lampMain.text = "Нет ответа"
                    lampMain.setTextColor(0xFFFF827A.toInt())
                    lampSub.text = e.message ?: "Ошибка HTTP"
                }
            }
        }
    }

    private fun sendControllerCommand(command: String): Int {
        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        val baseValue = prefs.getString("controller_base", "http://192.168.0.10")?.trim().orEmpty()
        val savedRoute = prefs.getString("controller_route", "/cmd?name={command}")?.trim().orEmpty()
        val template = if (savedRoute.isBlank() || savedRoute == "/ir?code={code}") "/cmd?name={command}" else savedRoute
        val path = template.replace("{command}", command).replace("{code}", command)
        val addressBase = if (baseValue.startsWith("http://", true) || baseValue.startsWith("https://", true)) baseValue else "http://$baseValue"
        val url = URL(addressBase.trimEnd('/') + (if (path.startsWith("/")) path else "/$path"))
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 2500
        connection.readTimeout = 2500
        connection.useCaches = false
        return try {
            connection.connect()
            val code = connection.responseCode
            try { if (code >= 400) connection.errorStream?.close() else connection.inputStream?.close() } catch (_: Exception) { }
            code
        } finally {
            connection.disconnect()
        }
    }

    private fun applyImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    override fun onStart() {
        super.onStart()
        if (!receiverRegistered) {
            val filter = IntentFilter(LightVoiceService.ACTION_STATUS)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(statusReceiver, filter)
            receiverRegistered = true
        }
        val prefs = getSharedPreferences(LightVoiceService.PREFS, MODE_PRIVATE)
        val status = prefs.getString("voice_status", "Голосовой режим не запущен") ?: "Голосовой режим не запущен"
        updateVoiceStatus(status)
        val last = prefs.getString("last_recognized", "").orEmpty()
        if (last.isNotBlank()) { resultView.text = last; resultView.visibility = View.VISIBLE } else { resultView.visibility = View.GONE }
    }

    override fun onStop() {
        if (receiverRegistered) {
            unregisterReceiver(statusReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        applyInterfaceBrightness()
        refreshWeather(false)
    }

    override fun onDestroy() {
        handler.removeCallbacks(dateTick)
        handler.removeCallbacks(hideControlPanelRunnable)
        if (!commandExecutor.isShutdown) commandExecutor.shutdownNow()
        if (!weatherExecutor.isShutdown) weatherExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun makeText(value: String, sizeSp: Float, color: Int): TextView = TextView(this).apply {
        text = value
        textSize = sizeSp
        setTextColor(color)
        includeFontPadding = false
    }

    private fun roundedGradient(top: Int, bottom: Int, strokeColor: Int, radius: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(top, bottom)).apply {
            cornerRadius = radius
            setStroke(dp(1), strokeColor)
        }

    private fun rounded(color: Int, strokeColor: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius; setStroke(dp(1), strokeColor)
    }

    private fun wrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun hideKeyboard(view: View) {
        try {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
            view.clearFocus()
        } catch (_: Exception) { }
    }

    private data class ControlItem(
        val icon: String,
        val label: String,
        val commands: List<String>,
        val accent: Int = TEXT_BRIGHT,
        val primary: Boolean = false
    )

    companion object {
        private const val REQUEST_RECORD_AUDIO = 101
        private const val WEATHER_REFRESH_MS = 30L * 60L * 1000L
        private val TEXT_BRIGHT = 0xFFE6E7EB.toInt()
        private val TEXT_MUTED = 0xFF9498A5.toInt()
        private val AMBER = 0xFFFFA447.toInt()
        private val AMBER_MUTED = 0xFFAD793E.toInt()
    }
}
