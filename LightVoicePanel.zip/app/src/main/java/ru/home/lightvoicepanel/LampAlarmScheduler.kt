package ru.home.lightvoicepanel

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** Weekly recurring lamp alarm. Weekday mask uses bit 0 = Monday ... bit 6 = Sunday. */
object LampAlarmScheduler {
    const val ACTION_FIRE = "ru.home.lightvoicepanel.LAMP_ALARM_FIRE"
    private const val REQUEST_CODE = 7814
    private const val PREF_ENABLED = "lamp_alarm_enabled"
    private const val PREF_WEEKDAYS_MASK = "lamp_alarm_weekdays_mask"
    private const val PREF_HOUR = "lamp_alarm_hour"
    private const val PREF_MINUTE = "lamp_alarm_minute"

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, LampAlarmReceiver::class.java).setAction(ACTION_FIRE)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags)
    }

    fun cancel(context: Context) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.cancel(pendingIntent(context))
    }

    /** Schedules the next selected weekday occurrence, then repeats from the receiver. */
    fun scheduleNext(context: Context, afterMillis: Long = System.currentTimeMillis()) {
        val prefs = context.getSharedPreferences(LightVoiceService.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(PREF_ENABLED, false)) {
            cancel(context)
            prefs.edit().remove("lamp_alarm_next_at").apply()
            return
        }
        val mask = prefs.getInt(PREF_WEEKDAYS_MASK, 0b00011111).and(0x7F)
        if (mask == 0) {
            cancel(context)
            prefs.edit().putBoolean(PREF_ENABLED, false).remove("lamp_alarm_next_at").apply()
            return
        }
        val hour = prefs.getInt(PREF_HOUR, 7).coerceIn(0, 23)
        val minute = prefs.getInt(PREF_MINUTE, 10).coerceIn(0, 59)
        val candidate = Calendar.getInstance().apply {
            timeInMillis = afterMillis
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        // At most one full week plus one day is needed to find a selected weekday.
        for (offset in 0..7) {
            val calendar = (candidate.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, offset) }
            val bit = when (calendar.get(Calendar.DAY_OF_WEEK)) {
                Calendar.MONDAY -> 1 shl 0
                Calendar.TUESDAY -> 1 shl 1
                Calendar.WEDNESDAY -> 1 shl 2
                Calendar.THURSDAY -> 1 shl 3
                Calendar.FRIDAY -> 1 shl 4
                Calendar.SATURDAY -> 1 shl 5
                else -> 1 shl 6
            }
            if ((mask and bit) != 0 && calendar.timeInMillis > afterMillis) {
                val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val pi = pendingIntent(context)
                if (Build.VERSION.SDK_INT >= 23) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pi)
                else manager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pi)
                prefs.edit().putLong("lamp_alarm_next_at", calendar.timeInMillis).apply()
                return
            }
        }
        // Defensive fallback; a non-empty weekly mask should always find an occurrence.
        cancel(context)
        prefs.edit().remove("lamp_alarm_next_at").apply()
    }

    fun commandsForMode(mode: String): List<String> = when (mode) {
        "night" -> listOf("night", "warmer", "darker", "darker")
        "20" -> listOf("20")
        "50" -> listOf("50")
        "100" -> listOf("100")
        "3000" -> listOf("3000")
        "4000" -> listOf("4000")
        "6500" -> listOf("6500")
        "warmer" -> listOf("warmer")
        "cooler" -> listOf("cooler")
        else -> listOf("100")
    }
}
