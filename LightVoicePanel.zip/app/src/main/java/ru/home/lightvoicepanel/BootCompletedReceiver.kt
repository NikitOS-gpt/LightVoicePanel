package ru.home.lightvoicepanel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restores the next scheduled lamp alarm after a reboot or application update. */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> LampAlarmScheduler.scheduleNext(context.applicationContext)
        }
    }
}
