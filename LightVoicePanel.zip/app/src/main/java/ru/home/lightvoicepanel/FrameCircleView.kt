package ru.home.lightvoicepanel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.View

/** Round button well containing a crisp microphone glyph. */
class FrameCircleView(context: Context, private val tint: Int) : View(context) {
    private val density = resources.displayMetrics.density
    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tint
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF21180F.toInt(), 0xFF111012.toInt())
        ).apply {
            shape = GradientDrawable.OVAL
            setStroke((density).toInt().coerceAtLeast(1), 0xFF3D2A1C.toInt())
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val u = density
        val mic = RectF(cx - 4.5f * u, cy - 10f * u, cx + 4.5f * u, cy + 3f * u)
        canvas.drawRoundRect(mic, 5f * u, 5f * u, iconPaint)
        val path = android.graphics.Path().apply {
            moveTo(cx - 8.5f * u, cy - 1f * u)
            lineTo(cx - 8.5f * u, cy + 0.3f * u)
            cubicTo(cx - 8.5f * u, cy + 7f * u, cx + 8.5f * u, cy + 7f * u, cx + 8.5f * u, cy + 0.3f * u)
            lineTo(cx + 8.5f * u, cy - 1f * u)
        }
        canvas.drawPath(path, iconPaint)
        canvas.drawLine(cx, cy + 7f * u, cx, cy + 10f * u, iconPaint)
        canvas.drawLine(cx - 4f * u, cy + 10f * u, cx + 4f * u, cy + 10f * u, iconPaint)
    }
}
