package ru.home.lightvoicepanel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min
import kotlin.math.sin

/**
 * Bitmap-based Nixie clock.
 * The glass assembly is the user's nixie_board.png background. Each numeral is a separate
 * supplied bitmap, scaled to 80% of its native size and screen-blended into the tube aperture.
 * No programmatically drawn mesh or cathode paths are used.
 */
class NixieClockView(context: Context) : View(context) {
    private val board: Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.nixie_board)
    private val digits: Array<Bitmap?> = arrayOf(
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_0),
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_1),
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_2),
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_3),
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_4),
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_5),
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_6),
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_7),
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_8),
        BitmapFactory.decodeResource(resources, R.drawable.nixie_digit_9)
    )

    // Coordinates are in the supplied 965x480 nixie_board.png image, not old 1185x587 space.
    // Each center is aligned to the actual dark glass aperture in the background bitmap.
    private val windows = arrayOf(
        RectF(105f, 118f, 255f, 324f),
        RectF(291f, 118f, 426f, 324f),
        RectF(553f, 118f, 707f, 324f),
        RectF(740f, 118f, 885f, 324f)
    )
    private val windowClips: List<Path> = windows.map { r ->
        Path().apply { addRoundRect(r, 13f, 13f, Path.Direction.CW) }
    }
    private val timeFormat = SimpleDateFormat("HHmm", Locale.US)
    private val boardPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val digitPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        // The user's bitmaps contain their own digit and mesh artwork. Screen blending removes
        // their dark rectangular background optically, leaving the lit tube detail over glass.
        xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
        alpha = 255
    }
    private val fallbackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFA447.toInt()
        textAlign = Paint.Align.CENTER
        textSize = 46f
    }
    private val sourceRect = Rect()
    private val destRect = RectF()

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isFocusable = false
        contentDescription = "Газоразрядные часы"
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val bg = board
        if (bg == null) {
            canvas.drawText(timeFormat.format(Date()), w / 2f, h / 2f, fallbackPaint)
            return
        }

        // Fit the real image dimensions, preserving its aspect ratio. All overlays use the same
        // canvas transform, so they cannot drift sideways relative to the photographed tubes.
        val bitmapW = bg.width.toFloat()
        val bitmapH = bg.height.toFloat()
        val scale = min(w / bitmapW, h / bitmapH)
        val left = (w - bitmapW * scale) / 2f
        val top = (h - bitmapH * scale) / 2f
        canvas.save()
        canvas.translate(left, top)
        canvas.scale(scale, scale)
        canvas.drawBitmap(bg, 0f, 0f, boardPaint)

        val shownTime = timeFormat.format(Date())
        val now = System.currentTimeMillis()
        // Very gentle fluctuation, applied to the supplied Bitmap itself, not to drawn paths.
        val pulse = (247f + 8f * sin(now * 0.0012)).toInt().coerceIn(238, 255)
        digitPaint.alpha = pulse

        for (i in 0 until 4) {
            val digitValue = shownTime[i].digitToIntCompat()
            val digitBitmap = digits.getOrNull(digitValue) ?: continue
            val window = windows[i]
            val clip = windowClips[i]

            // Exactly 80% of the original digit bitmap dimensions (175x274 -> 140x219.2).
            // Center both axes on the glass aperture to prevent lateral shifts between tubes.
            val targetW = digitBitmap.width * 0.80f
            val targetH = digitBitmap.height * 0.80f
            val centerX = window.centerX()
            val centerY = window.centerY()
            // Fine alignment requested for the first three tubes: shift only their Bitmap
            // artwork right by 7 image pixels; keep the glass aperture and clipping unchanged.
            val xOffset = if (i == 0 || i == 1 || i == 2) 7f else 0f
            destRect.set(
                centerX - targetW / 2f + xOffset,
                centerY - targetH / 2f,
                centerX + targetW / 2f + xOffset,
                centerY + targetH / 2f
            )

            canvas.save()
            canvas.clipPath(clip)
            sourceRect.set(0, 0, digitBitmap.width, digitBitmap.height)
            canvas.drawBitmap(digitBitmap, sourceRect, destRect, digitPaint)
            canvas.restore()
        }

        digitPaint.alpha = 255
        canvas.restore()
        if (isShown) postInvalidateDelayed(100L)
    }

    private fun Char.digitToIntCompat(): Int = this - '0'
}
