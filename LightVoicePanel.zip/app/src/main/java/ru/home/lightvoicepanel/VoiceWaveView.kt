package ru.home.lightvoicepanel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sin

/** Subtle animated amber waveform used in the dashboard's listening indicator. */
class VoiceWaveView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    @Volatile private var active = true

    fun setActive(value: Boolean) {
        active = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val now = SystemClock.uptimeMillis() / 240.0
        val bars = 11
        val barGap = w / (bars + 1f)
        paint.strokeWidth = 2f * density
        for (i in 0 until bars) {
            val phase = i * 0.92
            val wave = abs(sin(now + phase))
            val secondary = abs(sin(now * 0.54 + phase * 1.7))
            val normalized = if (active) 0.16 + wave * 0.66 + secondary * 0.18 else 0.14 + (i % 3) * 0.025
            val barHeight = (h * normalized.toFloat()).coerceAtLeast(3f * density)
            val x = barGap * (i + 1)
            paint.color = if (active) 0xFFFF8B35.toInt() else 0xFF4D4036.toInt()
            paint.alpha = if (active) (150 + wave * 105).toInt().coerceIn(150, 255) else 110
            canvas.drawLine(x, h / 2f - barHeight / 2f, x, h / 2f + barHeight / 2f, paint)
        }
        if (isShown) postInvalidateDelayed(if (active) 70L else 220L)
    }
}
